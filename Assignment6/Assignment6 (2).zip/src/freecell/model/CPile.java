package freecell.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class CPile {

  List<Stack<Card>> cPileImpl = new ArrayList<Stack<Card>>();

  protected CPile(int numberOfPiles) {

  }

  //Check if different color, and one digit lower
  protected void addCard(Card inputCard, int index) {

  }

  //Check if not empty, then pop
  protected void removeCard(Card inputCard, int index) {

  }

  protected String print() {

  }



}
