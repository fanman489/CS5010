package freecell.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class FPile {

  List<Stack<Card>> fPileImpl = new ArrayList<Stack<Card>>();

  protected FPile() {

  }

  //Check if same suit, and one digit higher
  protected void addCard(Card inputCard, int index) {

  }

  protected boolean checkGameOver() {

  }

  protected String print() {

  }

}
