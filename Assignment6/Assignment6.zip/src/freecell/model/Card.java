package freecell.model;

public class Card {

  int cardNumber;
  enum suit {SPADE, DIAMOND, CLUB, HEART};
  int priority;

  public boolean checkCascade(Card input) {
    return true;
  }

  public boolean checkFoundation(Card input) {
    return true;
  }

  protected void setPriority() {

  }


}
