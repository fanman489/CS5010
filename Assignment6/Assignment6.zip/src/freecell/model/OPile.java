package freecell.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class OPile {

  List<Stack<Card>> oPileImpl = new ArrayList<Stack<Card>>();

  protected OPile(int numberOfPiles) {

  }

  //Check if stack is empty, if empty then add card
  protected void addCard(Card inputCard, int index) {

  }

  //Check if not empty, then pop
  protected void removeCard(Card inputCard, int index) {

  }

  protected String print() {

  }

}
