package Questions;

import java.util.List;
import java.util.ArrayList;
import static java.lang.Character.isDigit;
import java.util.Collections;


public class MultipleAnswerQuestion extends MultipleChoiceQuestion {


  MultipleAnswerQuestion (String questionInput, String inputCorrectAnswer, String ... answer){
    super(questionInput, inputCorrectAnswer, answer);
  }


  public String inputAnswer(String inputAnswer) {

    String answer = convertAnswer(inputAnswer);
    String checkAnswer = convertAnswer(this.correctAnswer);

    if (answer == null || checkAnswer == null){
      return "Incorrect";
    }

    if (checkAnswer.equals(answer)) {
      return "Correct";
    } else {
      return "Incorrect";
    }
  }





  private String convertAnswer(String input) {
    String inputAnswer = null;
    ArrayList<String> inputNumbers = new ArrayList<>();

    for (int i = 0; i < input.length(); i += 2) {

      if (isDigit(input.charAt(i))) {

        inputNumbers.add(Character.toString(input.charAt(i)));

      } else {
        return "1";
      }
    }

    for (int i = 1; i < input.length(); i += 2) {
      if (input.charAt(i) == ' ') {
      } else {
        return "2";
      }
    }

    Collections.sort(inputNumbers);

    for (int i = 0; i < inputNumbers.size(); i++) {
        inputAnswer = String.join("", inputNumbers);
    }

    return inputAnswer;
  }


  @Override
  protected boolean equalsMultipleAnswer(MultipleAnswerQuestion other){
    return this.toString().compareToIgnoreCase(other.toString()) == 0;
  }

  @Override
  protected boolean equalsMultipleChoice(MultipleChoiceQuestion other){
    return false;
  }



  public boolean equals(Object other) {
    if (other instanceof AbstractQuestion) {
      AbstractQuestion q = (AbstractQuestion) other;
      return q.equalsMultipleAnswer(this);
    }
    return false;
  }





}
