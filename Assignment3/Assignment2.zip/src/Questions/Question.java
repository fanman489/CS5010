package Questions;

public interface Question {


  /**
   * Displays the question and asks user to input answer.
   * @return
   */
  String inputAnswer(String input);


  boolean equals(Object other);


}
