package Questions;

public class YesNoQuestion extends AbstractQuestion {


  YesNoQuestion(String inputQuestion, String inputCorrectAnswer) {

    question = inputQuestion;
    correctAnswer = inputCorrectAnswer;

  }




  public String inputAnswer(String input) {
    if (input.equals(this.correctAnswer)) {
      return "Correct.";
    } else {
      return "Incorrect.";
    }

  }

  @Override
  public String toString() {
    String output = null;
    output = question;

    return output;
  }


  @Override
  protected boolean equalsYesNo(YesNoQuestion other){
    return this.toString().compareToIgnoreCase(other.toString()) == 0;
  }


  public boolean equals(Object other) {
    if (other instanceof AbstractQuestion) {
      AbstractQuestion q = (AbstractQuestion) other;
      return q.equalsYesNo(this);
    }
    return false;
  }





}
