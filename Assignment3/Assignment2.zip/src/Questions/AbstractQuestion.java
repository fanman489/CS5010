package Questions;

public abstract class AbstractQuestion implements Question {

  String question;
  String correctAnswer;

  protected boolean equalsYesNo(YesNoQuestion other) {
    return false;
  }

  protected boolean equalsLikert(LikertQuestion other) {
    return false;
  }

  protected boolean equalsMultipleChoice(MultipleChoiceQuestion other) {
    return false;
  }

  protected boolean equalsMultipleAnswer(MultipleAnswerQuestion other) {
    return false;
  }



}
