package Questions;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;


public class MultipleChoiceQuestion extends AbstractQuestion {

  private List<String> multipleAnswers = new ArrayList<>();


  MultipleChoiceQuestion (String questionInput, String inputCorrectAnswer, String ... answer){

    question = questionInput;
    correctAnswer = inputCorrectAnswer;


    for (String i : answer) {
      this.multipleAnswers.add(i);

    }
  }


  public String inputAnswer(String input) {
    if (input == this.correctAnswer) {
      return "Correct.";
    } else {
      return "Incorrect.";
    }
  }


  public String toString(){

    String output;
    output = this.question;

    for (int i = 0; i < this.multipleAnswers.size(); i++) {
      output = output + " ["  + i + "] " + this.multipleAnswers.get(i);
    }

    return output;

  }


  @Override
  protected boolean equalsMultipleChoice(MultipleChoiceQuestion other){
    return this.toString().compareToIgnoreCase(other.toString()) == 0;
  }


  public boolean equals(Object other) {
    if (other instanceof AbstractQuestion) {
      AbstractQuestion q = (AbstractQuestion) other;
      return q.equalsMultipleChoice(this);
    }
    return false;
  }






}
