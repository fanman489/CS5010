package Questions;


import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class QuestionnaireTest {


  @Test

public void testAdditionalTesting9() {

    QuestionnaireArray questionnaire = new QuestionnaireArray(new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda"), new YesNoQuestion("Do you drive?", "Yes"), new YesNoQuestion("Does your significant other drive?", "Yes"));
    questionnaire.sort();

  Assert.assertEquals(questionnaire.toString(), "");

}

  @Test
  public void testAdditionalTesting10() {

    QuestionnaireArray questionnaire = new QuestionnaireArray(new MultipleAnswerQuestion("Multiple Answer: What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda"), new MultipleChoiceQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda"), new YesNoQuestion("Do you drive?", "Yes"), new YesNoQuestion("Does your significant other drive?", "Yes"));
    questionnaire.sort();

    Assert.assertEquals(questionnaire.toString(), "");

  }



  @Test
  public void testAdditionalTesting11() {

    TypeComparator a = new TypeComparator();

    a.compare(new MultipleAnswerQuestion("Multiple Answer: What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda"), new MultipleChoiceQuestion("Multiple Answer: What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda"));


    Assert.assertEquals(a.compare(new MultipleAnswerQuestion("Multiple Answer: What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda"), new MultipleChoiceQuestion("Multiple Answer: What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda")), "");

  }



  @Test
  public void testAdditionalTesting12() {

    QuestionnaireArray questionnaire = new QuestionnaireArray(new MultipleAnswerQuestion("Multiple Answer: What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda"), new MultipleChoiceQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda"), new YesNoQuestion("Do you drive?", "Yes"), new YesNoQuestion("Does your significant other drive?", "Yes"), new YesNoQuestion("Does your significant other drive?", "Yes"));
    questionnaire.sort();

    Assert.assertEquals(questionnaire.toString(), "");

  }

}