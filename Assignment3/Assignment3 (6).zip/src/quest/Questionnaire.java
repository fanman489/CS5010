package quest;

public interface Questionnaire {

  String toString();

}
