package Questions;

public class EmptyNode implements Questionnaire {

  @Override
  public String toString(){
    return "";
  }

  public Questionnaire sortAlphabetical() {

    return new EmptyNode();
  }

  public Questionnaire insertAlphabet(Question question) {
    return new ElementNode(question, this);
  }

  public Questionnaire sortType() {

    return new EmptyNode();
  }

  public Questionnaire insertType(Question question) {
    return new ElementNode(question, this);
  }




}
