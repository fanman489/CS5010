package Questions;

public class ElementNode implements Questionnaire {

  Question question;
  Questionnaire rest;

  public ElementNode(Question q, Questionnaire listOfQuestions) {
    this.question = q;
    this.rest = listOfQuestions;
  }

  @Override
  public String toString() {
    return "(" + this.question.toString() + ")" + this.rest.toString();
  }

  public Questionnaire sortAlphabetical() {
    return this.rest.sortAlphabetical().insertType(question);
  }


  /*
  public Questionnaire sort() {


    Questionnaire sorted;
    sorted = this.sortAlphabetical();
    sorted = this.sortType();

    return sorted;

  }
  */


  public Questionnaire sortType() {

    return this.rest.sortType().insertType(question);

  }


  public Questionnaire insertAlphabet(Question q) {

    String a = this.question.toString();
    String b = q.toString();


    if (a.compareTo(b) < 0) {
      return new ElementNode(this.question, this.rest.insertAlphabet(q));
    } else {
      return new ElementNode(q, this);
    }
  }

  public Questionnaire insertType(Question q) {

    String a = this.question.toString();
    String b = q.toString();


    if (this.question.compareType(q)) {
      return new ElementNode(this.question, this.rest.insertType(q));
    } else if (a .compareTo(b) < 0) {
      return new ElementNode(this.question, this.rest.insertType(q));
    } else {
      return new ElementNode(q, this);
    }

  }


}




















