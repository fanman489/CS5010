package Questions;

public class YesNoQuestion extends AbstractQuestion {


  YesNoQuestion(String inputQuestion, String inputCorrectAnswer) {

    question = inputQuestion;
    correctAnswer = inputCorrectAnswer;

  }




  public String inputAnswer(String input) {
    if (input.equals(this.correctAnswer)) {
      return "Correct.";
    } else {
      return "Incorrect.";
    }

  }

  @Override
  public String toString() {
    String output = null;
    output = question;




    return output;
  }





}
