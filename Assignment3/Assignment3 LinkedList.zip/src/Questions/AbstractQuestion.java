package Questions;

public abstract class AbstractQuestion implements Question {

  String question;
  String correctAnswer;


  public Integer checkType() {


    if(this instanceof YesNoQuestion ) {
      return 1;
    } else if (this instanceof LikertQuestion) {
      return 2;
    } else if (this instanceof MultipleAnswerQuestion) {
      return 4;
    } else if (this instanceof MultipleChoiceQuestion) {
      return 3;
    } else {
      return null;
    }


  }


  public boolean compareType(Question a) {

    if (this.checkType() == a.checkType()){
      return true;
    } else {
      return false;
    }

  }









}
