package Questions;

public interface Questionnaire {

  Questionnaire sortAlphabetical();

  Questionnaire insertAlphabet(Question question);

  Questionnaire sortType();

  Questionnaire insertType(Question d);

}
