package Questions;
import java.util.List;
import java.util.ArrayList;


public class MultipleChoiceQuestion extends AbstractQuestion {

  private List<String> multipleAnswers = new ArrayList<>();


  MultipleChoiceQuestion (String questionInput, String inputCorrectAnswer, String ... answer){

    question = questionInput;
    correctAnswer = inputCorrectAnswer;


    for (String i : answer) {
      multipleAnswers.add(i);

    }
  }


  public String inputAnswer(String input) {
    if (input == this.correctAnswer) {
      return "Correct.";
    } else {
      return "Incorrect.";
    }
  }


  public String toString(){

    String output = null;
    output = this.question;

    for (int i = 0; i < this.multipleAnswers.size(); i++) {
      output = output + " ["  + i + "] " + this.multipleAnswers.get(i);
    }

    return output;

  }







}
