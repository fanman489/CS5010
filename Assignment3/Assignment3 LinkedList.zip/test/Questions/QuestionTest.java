package Questions;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class QuestionTest {




  @Test
  public void testOutput1() {
    Question drive = new YesNoQuestion("Do you drive?", "Yes");

    assertEquals(drive.inputAnswer("Yes"), "Correct.");
  }

  @Test
  public void testOutput2() {
    Question drive = new YesNoQuestion("Do you drive?", "Yes");

    assertEquals(drive.inputAnswer("No"), "Incorrect.");
  }

  @Test
  public void testOutput3() {
    Question drive = new YesNoQuestion("Do you drive?", "Yes");

    assertEquals(drive.inputAnswer("123"), "Incorrect.");
  }


  @Test
  public void testOuput4() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "1", "Honda", "Toyota", "Subaru");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Subaru");
    assertEquals(driveMult.inputAnswer("1"), "Correct.");
  }

  @Test
  public void testOuput5() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1", "Honda", "Toyota", "Subaru");


    assertEquals(driveMult.inputAnswer("1"), "Correct");
  }

  @Test
  public void testOuput6() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2", "Honda", "Toyota", "Subaru");


    assertEquals(driveMult.inputAnswer("1 2"), "Correct");
  }

  @Test
  public void testOuput7() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda");


    assertEquals(driveMult.inputAnswer("1 2 4"), "Correct");
  }


  @Test
  public void testOuput8() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda");


    assertEquals(driveMult.inputAnswer("1 4 2"), "Correct");
  }


  @Test
  public void testOuput9() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda");


    assertEquals(driveMult.inputAnswer("1 4 3 2"), "Incorrect");
  }


  @Test
  public void testOuput10() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda");


    assertEquals(driveMult.toString(), "Incorrect");
  }






}