package Questions;


import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class QuestionnaireTest {


  @Test
  public void testOutput1() {
    Questionnaire emptyListOfQuestions = new EmptyNode();

    Questionnaire newListOfQuestions = new ElementNode (
            new YesNoQuestion("xDo you drive?", "Yes"),
            new ElementNode( new MultipleChoiceQuestion("What do you drive?",
                    "1", "Honda", "Toyota", "Subaru"), new ElementNode(new YesNoQuestion("Are you over 21?", "Yes"), emptyListOfQuestions)));


    newListOfQuestions = newListOfQuestions.sortAlphabetical();
    assertEquals(newListOfQuestions.toString(), "");

  }





}