package quest;

public class HashFormula {

  public static int hashCode(String question, String correctAnswer) {
    return question.hashCode() + correctAnswer.hashCode();
  }


}
