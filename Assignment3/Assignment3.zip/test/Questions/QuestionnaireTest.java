package Questions;


import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class QuestionnaireTest {


  @Test
  public void testOutput1() {
    Questionnaire emptyListOfQuestions = new EmptyNode();

    Questionnaire newListOfQuestions = new ElementNode (new YesNoQuestion("Do you drive?", "Yes"), new ElementNode( new MultipleChoiceQuestion("What do you drive?", "1", "Honda", "Toyota", "Subaru"), emptyListOfQuestions));

    assertEquals(newListOfQuestions.toString(), "");

  }


}