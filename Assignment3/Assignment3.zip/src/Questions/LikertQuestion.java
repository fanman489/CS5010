package Questions;

public class LikertQuestion extends AbstractQuestion {


  LikertQuestion(String inputQuestion) {

    question = inputQuestion;

  }


  public String inputAnswer(String input) {


    Integer inputAnswer = null;

    try  {
      inputAnswer = Integer.parseInt(input);
    } catch (NumberFormatException ex) {
      return "Incorrect.";
    }

    if (inputAnswer <= 5 && inputAnswer > 0) {
      return "Correct.";
    } else {
      return "Incorrect.";
    }


  }

  @Override
  public String toString() {
    String output = null;
    output = question;


    output = output + "Correct Answer: " + correctAnswer;


    return output;
  }

}
