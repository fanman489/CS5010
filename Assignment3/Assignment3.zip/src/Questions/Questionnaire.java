package Questions;

public interface Questionnaire {



}
