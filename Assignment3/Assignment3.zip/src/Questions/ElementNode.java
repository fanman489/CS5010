package Questions;

public class ElementNode implements Questionnaire {

  Question question;
  Questionnaire rest;

  public ElementNode (Question q, Questionnaire listOfQuestions) {
    this.question = q;
    this.rest = listOfQuestions;
  }


  @Override
  public String toString() {
    return "(" + this.question.toString() + ")" + this.rest.toString();
  }


  


}
