package Questions;

public class EmptyNode implements Questionnaire {

  @Override
  public String toString(){
    return "";
  }

}
