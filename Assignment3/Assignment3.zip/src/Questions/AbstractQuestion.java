package Questions;

public abstract class AbstractQuestion implements Question {

  String question;
  String correctAnswer;



}
