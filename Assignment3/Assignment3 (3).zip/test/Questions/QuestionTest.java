package Questions;

import org.junit.Test;

import static org.junit.Assert.assertEquals;


import java.util.ArrayList;
import java.util.stream.Collectors;


public class QuestionTest {




  @Test
  public void testYesNo1() {
    Question drive = new YesNoQuestion("Do you drive?", "Yes");

    assertEquals(drive.inputAnswer("Yes"), "Correct.");
  }

  @Test
  public void testYesNo1a() {
    Question drive = new YesNoQuestion("Do you drive?", "Yes");

    assertEquals(drive.inputAnswer("YES"), "Correct.");
  }

  @Test
  public void testYesNo2() {
    Question drive = new YesNoQuestion("Do you drive?", "Yes");

    assertEquals(drive.inputAnswer("No"), "Incorrect.");
  }

  @Test
  public void testYesNo2a() {
    Question drive = new YesNoQuestion("Do you drive?", "NO");

    assertEquals(drive.inputAnswer("No"), "Correct.");
  }

  @Test
  public void testYesNo2b() {
    Question drive = new YesNoQuestion("" ,"NO");

    assertEquals(drive.inputAnswer("No"), "Correct.");
  }


  @Test
  public void testYesNo3() {
    Question drive = new YesNoQuestion("Do you drive?", "Yes");

    assertEquals(drive.inputAnswer("123"), "Incorrect.");
  }


  @Test
  public void testYesNo4() {
    Question drive = new YesNoQuestion("Do you drive?", "123");

    assertEquals(drive.inputAnswer("123"), "Incorrect.");
  }


  @Test
  public void Likert1() {
    Question drive = new LikertQuestion("Do you like driving?");

    assertEquals(drive.inputAnswer("12"), "Incorrect.");
  }

  @Test
  public void Likert2() {
    Question drive = new LikertQuestion("Do you like driving?");

    assertEquals(drive.inputAnswer("5"), "Correct.");
  }

  @Test
  public void Likert3() {
    Question drive = new LikertQuestion("Do you like driving?");

    assertEquals(drive.inputAnswer("6"), "Incorrect.");
  }

  @Test
  public void Likert2a() {
    Question drive = new LikertQuestion("Do you like driving?");

    assertEquals(drive.inputAnswer("5"), "Correct.");
  }


  @Test
  public void likert2b() {
    Question drive = new LikertQuestion("Do you like driving?");

    assertEquals(drive.inputAnswer("4"), "Correct.");
  }


  @Test
  public void likert2c() {
    Question drive = new LikertQuestion("Do you like driving?");

    assertEquals(drive.inputAnswer("3"), "Correct.");
  }


  @Test
  public void likert2d() {
    Question drive = new LikertQuestion("Do you like driving?");

    assertEquals(drive.inputAnswer("2"), "Correct.");
  }

  @Test
  public void likert2e() {
    Question drive = new LikertQuestion("Do you like driving?");

    assertEquals(drive.inputAnswer("1"), "Correct.");
  }


  @Test
  public void likert2f() {
    Question drive = new LikertQuestion("Do you like driving?");

    assertEquals(drive.inputAnswer("1"), "Correct.");
  }

  @Test
  public void likert2g() {
    Question drive = new LikertQuestion("Do you like driving?");

    assertEquals(drive.inputAnswer("0"), "Incorrect.");
  }


  @Test
  public void likert2h() {
    Question drive = new LikertQuestion("Do you like driving?");

    assertEquals(drive.inputAnswer("A"), "Incorrect.");
  }








  @Test
  public void multipleChoice1() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "1", "Honda", "Toyota", "Subaru");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Subaru");
    assertEquals(driveMult.inputAnswer("1"), "Correct.");
  }


  @Test
  public void multipleChoice2() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "0", "Honda", "Toyota", "Subaru");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Subaru");
    assertEquals(driveMult.inputAnswer("1"), "Correct.");
  }

  @Test
  public void multipleChoice3() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "4", "Honda", "Toyota", "Subaru");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Subaru");
    assertEquals(driveMult.inputAnswer("2"), "Correct.");
  }


  @Test
  public void multipleChoice4() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "3", "Honda", "Toyota", "Subaru");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Subaru");
    assertEquals(driveMult.inputAnswer("3"), "Correct.");
  }



  @Test
  public void multipleChoice5() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "1", "Honda", "Toyota");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Subaru");
    assertEquals(driveMult.inputAnswer("1"), "Correct.");
  }


  @Test
  public void multipleChoice6() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "1", "Honda", "Toyota", "Nissan", "Kia", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Subaru");
    assertEquals(driveMult.inputAnswer("1"), "Correct.");
  }

  @Test
  public void multipleChoice7() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "a", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Subaru");
    assertEquals(driveMult.inputAnswer("1"), "Correct.");
  }


  @Test
  public void multipleChoice8() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "7", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("7"), "Correct.");
  }

  @Test
  public void multipleChoice9() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "7", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("7a"), "Correct.");
  }

  @Test
  public void multipleChoice10() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "7a", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("7a"), "Correct.");
  }

  @Test
  public void multipleChoice11() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "7a", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("7"), "Correct.");
  }









  @Test
  public void multipleAnswer1a() {
    Question driveMult = new MultipleChoiceQuestion("What do you drive?", "1", "Honda", "Toyota");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Subaru");
    assertEquals(driveMult.inputAnswer("1"), "Correct.");
  }


  @Test
  public void multipleAnswer1() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1", "Honda", "Toyota", "Nissan", "Kia", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Subaru");
    assertEquals(driveMult.inputAnswer("1"), "Correct.");
  }

  @Test
  public void multipleAnswer2() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "a", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Subaru");
    assertEquals(driveMult.inputAnswer("1"), "Correct.");
  }


  @Test
  public void multipleAnswer3() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "7", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("7"), "Correct.");
  }


  @Test
  public void multipleAnswer4() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "7 a", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("7 3"), "Correct.");
  }


  @Test
  public void multipleAnswer5() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "73", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("7 3"), "Correct.");
  }


  @Test
  public void multipleAnswer6() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "7 3", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("7 3"), "Correct.");
  }


  @Test
  public void multipleAnswer7() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "3 7", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("7 3"), "Correct.");
  }


  @Test
  public void multipleAnswer8() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "3 7 1 3 4", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("3 7 1 4"), "Correct.");
  }

  @Test
  public void multipleAnswer9() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "3 7 1 3 3 3 4", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("3 7 1 4 4 1 1 7"), "Correct.");
  }


  @Test
  public void multipleAnswer10() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("1"), "Correct.");
  }

  @Test
  public void multipleAnswer11() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1a", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("1"), "Correct.");
  }



  @Test
  public void multipleAnswer12() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2 5 4", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("4 2 5 1"), "Correct.");
  }

  @Test
  public void multipleAnswer13() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2 5 4", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("42 51"), "Correct.");
  }


  @Test
  public void multipleAnswer14() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "4 2 5 1", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("4 2 5 1 3"), "Incorrect.");
  }



  @Test
  public void multipleAnswer14a() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "4 2 5 1", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("4 2 3"), "Incorrect.");
  }


  @Test
  public void multipleAnswer14b() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "4 2 5 1 4 2 5 3", "Honda", "Toyota", "Nissan", "Subaru", "Mitsubishi", "Mazda", "Lexus", "Acura");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Nissan [3] Subaru [4] Mitsubishi [5] Mazda [6] Lexus [7] Acura");
    assertEquals(driveMult.inputAnswer("4 2 3 5 1 5 1"), "Correct.");
  }



  @Test
  public void multipleAnswer15() {
    ArrayList<String> driveMult = new ArrayList<>();
    driveMult.add("1");
    driveMult.add("1");


    driveMult = (ArrayList<String>) driveMult.stream().distinct().collect(Collectors.toList());

    assertEquals(driveMult.toString(), "[1]");

  }









  @Test
  public void MultipleAnswer() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1", "Honda", "Toyota", "Subaru");

    assertEquals(driveMult.toString(), "What do you drive? [0] Honda [1] Toyota [2] Subaru");

  }

  @Test
  public void testOuput5() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1", "Honda", "Toyota", "Subaru");


    assertEquals(driveMult.inputAnswer("1"), "Correct.");
  }

  @Test
  public void testOuput6() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2", "Honda", "Toyota", "Subaru");


    assertEquals(driveMult.inputAnswer("1 2"), "Correct.");
  }

  @Test
  public void testOuput7() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda");


    assertEquals(driveMult.inputAnswer("1 2 4"), "Correct.");
  }


  @Test
  public void testOuput8() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda");


    assertEquals(driveMult.inputAnswer("1 4 2"), "Correct.");
  }


  @Test
  public void testOuput9() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda");


    assertEquals(driveMult.inputAnswer("1 4 3 2"), "Incorrect.");
  }

  @Test
  public void testOuput9a() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2 4 3", "Honda", "Toyota", "Subaru", "Mazda");


    assertEquals(driveMult.inputAnswer("1 4 3"), "Incorrect.");
  }


  @Test
  public void testOuput10() {
    Question driveMult = new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda");


    assertEquals(driveMult.toString(), "Incorrect");
  }


  @Test
  public void testOuput11() {
    Question driveMultA = new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda");
    Question driveMultA1 = new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda");
    Question driveMultB = new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru");
    Question driveMultC = new MultipleAnswerQuestion("What do you drive?", "1", "Honda", "Toyota", "Subaru");


    Question driveMA = new MultipleChoiceQuestion("What do you drive?", "1", "Honda", "Toyota", "Nissan", "Kia", "Subaru", "Mitsubishi", "Mazda", "Lexus");
    Question driveM1 = new MultipleChoiceQuestion("What do you drive?", "1 2", "Honda", "Toyota", "Nissan", "Kia", "Subaru", "Mitsubishi", "Mazda", "Lexus");
    Question driveM2 = new MultipleChoiceQuestion("What do you drive?", "1", "Honda", "Toyota", "Nissan", "Kia", "Subaru", "Mitsubishi", "Mazda");


    Question driveYN1 = new YesNoQuestion("Do you drive?", "Yes");
    Question driveYN2 = new YesNoQuestion("Can you drive manual?", "Yes");
    Question driveYN3 = new YesNoQuestion("Is your insurance valid?", "Yes");

    Question driveL1 = new LikertQuestion("Do you like driving?");
    Question driveL2 = new LikertQuestion("How is your driving skill?");
    Question driveL3 = new LikertQuestion("What would you rate your current car?");


    assertEquals(driveMultA.equals(driveMultA), true);
    assertEquals(driveMultA.equals(driveMultC), false);
    assertEquals(driveMultA.equals(driveMultA1), true);
    assertEquals(driveMultA.equals(driveMultB), false);
    assertEquals(driveMultB.equals(driveMultC), true);
    assertEquals(driveMultA1.equals(driveMultB), false);
    assertEquals(driveMultA.equals(driveMA), false);
    assertEquals(driveMultC.equals(driveMultB), true);

    assertEquals(driveMA.equals(driveM1), true);
    assertEquals(driveM1.equals(driveMA), true);
    assertEquals(driveM1.equals(driveM2), false);

    assertEquals(driveM1.equals(driveL1), false);
    assertEquals(driveM1.equals(driveYN3), false);


  }






}