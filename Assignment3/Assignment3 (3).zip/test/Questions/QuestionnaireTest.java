package Questions;


import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class QuestionnaireTest {


  QuestionnaireArray questionnaire = new QuestionnaireArray(
          new MultipleAnswerQuestion("What do you drive?", "1 2 4", "Honda", "Toyota", "Subaru", "Mazda"),
          new YesNoQuestion("Do you drive?", "Yes"),
          new YesNoQuestion("Does your significant other drive?", "Yes"));

  QuestionnaireArray sorted = new QuestionnaireArray(

          new YesNoQuestion("Can you drive manual?", "Yes"),
          new YesNoQuestion("Do you drive?", "Yes"),
          new YesNoQuestion("Is your insurance valid?", "Yes"),

          new LikertQuestion("Do you like driving?"),
          new LikertQuestion("How is your driving skill?"),
          new LikertQuestion("What would you rate your current car?"),


          new MultipleChoiceQuestion("Do you know which model is most reliable?", "2", "Honda", "Toyota", "Subaru"),
          new MultipleChoiceQuestion("Is there a model that is least reliable?", "3", "Honda", "Toyota", "Subaru"),
          new MultipleChoiceQuestion("What do you drive?", "1", "Honda", "Toyota", "Subaru", "Mazda"),
          new MultipleChoiceQuestion("What is your favorite make?", "1", "Honda", "Toyota", "Subaru", "Mazda"),

          new MultipleAnswerQuestion("Can you pick the models which do not make SUVs?", "3 5", "Honda", "Toyota", "Nissan", "Kia", "Subaru", "Mitsubishi", "Mazda"),
          new MultipleAnswerQuestion("Select the models that are luxury models.", "1 2", "Honda", "Toyota", "Nissan", "Kia", "Subaru", "Mitsubishi", "Mazda", "Lexus"),
          new MultipleAnswerQuestion("Which models are Japanese models?", "1 4", "Honda", "Toyota", "Nissan", "Kia", "Subaru", "Mitsubishi", "Mazda", "Lexus"));


  QuestionnaireArray unsorted = new QuestionnaireArray(


          new MultipleChoiceQuestion("Do you know which model is most reliable?", "2", "Honda", "Toyota", "Subaru"),
          new YesNoQuestion("Is your insurance valid?", "Yes"),
          new MultipleAnswerQuestion("Select the models that are luxury models.", "1 2", "Honda", "Toyota", "Nissan", "Kia", "Subaru", "Mitsubishi", "Mazda", "Lexus"),
          new LikertQuestion("Do you like driving?"),
          new MultipleChoiceQuestion("What do you drive?", "1", "Honda", "Toyota", "Subaru", "Mazda"),
          new LikertQuestion("What would you rate your current car?"),
          new YesNoQuestion("Do you drive?", "Yes"),
          new MultipleAnswerQuestion("Which models are Japanese models?", "1 4", "Honda", "Toyota", "Nissan", "Kia", "Subaru", "Mitsubishi", "Mazda", "Lexus"),
          new YesNoQuestion("Can you drive manual?", "Yes"),
          new MultipleChoiceQuestion("Is there a model that is least reliable?", "3", "Honda", "Toyota", "Subaru"),
          new MultipleAnswerQuestion("Can you pick the models which do not make SUVs?", "3 5", "Honda", "Toyota", "Nissan", "Kia", "Subaru", "Mitsubishi", "Mazda"),
          new MultipleChoiceQuestion("What is your favorite make?", "1", "Honda", "Toyota", "Subaru", "Mazda"),
          new LikertQuestion("How is your driving skill?"));





  @Test
  public void testAdditionalTesting9() {

    questionnaire.sort();

    assertEquals(questionnaire.toString(), "1. Do you drive? Input a choice between 1 to 5: \n" +
            "2. Does your significant other drive? Input a choice between 1 to 5: \n" +
            "3. What do you drive? [0] Honda [1] Toyota [2] Subaru [3] Mazda \n");

  }

  @Test
  public void testAdditionalTesting9a() {

    assertEquals(questionnaire.toString(), "1. What do you drive? [0] Honda [1] Toyota [2] Subaru [3] Mazda \n" +
            "2. Do you drive? Input a choice between 1 to 5: \n" +
            "3. Does your significant other drive? Input a choice between 1 to 5: \n");

  }









  @Test
  public void testAdditionalTesting13() {

    unsorted.sort();

    assertEquals(unsorted.toString(), sorted.toString());

  }

  @Test
  public void testAdditionalTesting14() {
    unsorted.sort();

    assertEquals(unsorted.toString(), unsorted.toString());

  }

}