package Questions;

public class YesNoQuestion extends AbstractQuestion {


  YesNoQuestion(String inputQuestion, String inputCorrectAnswer) throws IllegalArgumentException {


    super(inputQuestion, inputCorrectAnswer);

    if (question.isEmpty() || correctAnswer.isEmpty()) {
      throw new IllegalArgumentException ("Need to input question and answer.");
    }

    if (correctAnswer.equalsIgnoreCase("Yes") || correctAnswer.equalsIgnoreCase("No")) {
      return;
    } else {
      throw new IllegalArgumentException ("Need to input either Yes or No as the answer.");
    }
  }

  @Override
  public String inputAnswer(String input) {
    if (input.equalsIgnoreCase(this.correctAnswer)) {
      return "Correct.";
    } else {
      return "Incorrect.";
    }
  }

  @Override
  public String toString() {

    return question + " Input either yes or no:";
  }


  @Override
  protected boolean equalsYesNo(YesNoQuestion other){
    return this.toString().compareToIgnoreCase(other.toString()) == 0;
  }

  @Override
  public boolean equals(Object other) {
    if (other instanceof AbstractQuestion) {
      AbstractQuestion q = (AbstractQuestion) other;
      return q.equalsYesNo(this);
    }
    return false;
  }





}
