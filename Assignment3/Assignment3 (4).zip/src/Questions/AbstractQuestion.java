package Questions;

public abstract class AbstractQuestion implements Question {

  final String question;
  final String correctAnswer;


  public AbstractQuestion(String q, String a){
    question = q;
    correctAnswer = a;
  }

  public AbstractQuestion(String q) {
    question = q;
    correctAnswer = null;
  }


  protected boolean equalsYesNo(YesNoQuestion other) {
    return false;
  }

  protected boolean equalsLikert(LikertQuestion other) {
    return false;
  }

  protected boolean equalsMultipleChoice(MultipleChoiceQuestion other) {
    return false;
  }

  protected boolean equalsMultipleAnswer(MultipleAnswerQuestion other) {
    return false;
  }



}
