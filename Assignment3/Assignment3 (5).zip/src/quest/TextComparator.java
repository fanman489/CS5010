package quest;
import java.util.Comparator;

public class TextComparator<Question> implements Comparator<Question> {

  public int compare(Question a, Question b){

    return a.toString().compareToIgnoreCase(b.toString());

  }



}
