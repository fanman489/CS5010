package quest;
import java.util.Comparator;

public class TypeComparator<Question> implements Comparator<Question> {


  public int compare(Question a, Question b) {

    if (TypeComparator.checkType(a) > (TypeComparator.checkType(b))) {
      return 1;
    } else if (TypeComparator.checkType(a) < TypeComparator.checkType(b)) {
      return -1;
    } else {
      return 0;
    }

  }


  private static Integer checkType(Object a) {

    if(a instanceof YesNoQuestion) {
      return 1;
    } else if (a instanceof LikertQuestion) {
      return 2;
    } else if (a instanceof MultipleAnswerQuestion) {
      return 4;
    } else if (a instanceof MultipleChoiceQuestion) {
      return 3;
    } else {
      return null;
    }

  }


}
