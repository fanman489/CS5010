package quest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collectors;

import static java.lang.Character.isDigit;


public class MultipleAnswerQuestion extends MultipleChoiceQuestion {



  MultipleAnswerQuestion (String questionInput, String inputCorrectAnswer, String ... answer){
    super(questionInput, inputCorrectAnswer, answer);



    if (correctAnswer.length() > answer.length*2 - 1) {
      throw new IllegalArgumentException("Invalid correct answer.");
    }

    for (int i = 0; i < correctAnswer.length(); i += 2) {
      if (!isDigit(correctAnswer.charAt(i))) {
       throw new IllegalArgumentException("Invalid correct answer.");
      }
    }

    for (int i = 1; i < correctAnswer.length(); i += 2) {
      if (correctAnswer.charAt(i) != ' ') {
        throw new IllegalArgumentException("Invalid correct answer.");
      }
    }
  }


  @Override
  public String inputAnswer(String inputAnswer) {

    String answer = convertAnswer(inputAnswer);
    String checkAnswer = convertAnswer(this.correctAnswer);

    if (answer == null || checkAnswer == null){
      return "Incorrect.";
    }

    if (checkAnswer.equals(answer)) {
      return "Correct.";
    } else {
      return "Incorrect.";
    }
  }





  private String convertAnswer(String input) {
    String inputAnswer = null;
    ArrayList<String> inputNumbers = new ArrayList<>();
    ArrayList<String> inputNumbersUnique;

    for (int i = 0; i < input.length(); i += 2) {
      if (isDigit(input.charAt(i))) {
        inputNumbers.add(Character.toString(input.charAt(i)));
      } else {
        return null;
      }
    }

    for (int i = 1; i < input.length(); i += 2) {
      if (input.charAt(i) == ' ') {
      } else {
        return null;
      }
    }

    Collections.sort(inputNumbers);
    inputNumbersUnique = (ArrayList<String>) inputNumbers.stream().distinct().collect(Collectors.toList());




    for (int i = 0; i < inputNumbers.size(); i++) {
        inputAnswer = String.join("", inputNumbersUnique);
    }


    return inputAnswer;
  }


  @Override
  protected boolean equalsMultipleAnswer(MultipleAnswerQuestion other){
    return this.toString().compareToIgnoreCase(other.toString()) == 0;
  }

  @Override
  protected boolean equalsMultipleChoice(MultipleChoiceQuestion other){
    return false;
  }


  @Override
  public boolean equals(Object other) {
    if (other instanceof AbstractQuestion) {
      AbstractQuestion q = (AbstractQuestion) other;
      return q.equalsMultipleAnswer(this);
    }
    return false;
  }





}
