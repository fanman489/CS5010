package quest;

public class LikertQuestion extends AbstractQuestion {


  LikertQuestion(String inputQuestion) throws IllegalArgumentException {

    super(inputQuestion);

    if (question.isEmpty()) {
      throw new IllegalArgumentException ("Question input is blank");
    }
  }


  @Override
  public String inputAnswer(String input) {



    try  {
      if (input.length() > 1) {
        return "Incorrect.";
      }

    } catch (NumberFormatException ex) {
      return "Incorrect.";
    }


    if(Character.isDigit(input.charAt(0))) {
      if (Character.getNumericValue( input.charAt(0)) <= 0 || Character.getNumericValue( input.charAt(0)) > 5) {
        throw new IllegalArgumentException ("Answer should be an integer from 1 to 5.");
      } else {
        return "Correct";
      }
    } else {
      return "Incorrect";
    }


  }

  @Override
  public String toString() {
    String output;
    output = question + " Input a choice between 1 to 5:";

    return output;
  }


  @Override
  protected boolean equalsLikert(LikertQuestion other) {
    return this.toString().compareToIgnoreCase(other.toString()) == 0;
  }


  @Override
  public boolean equals(Object other) {
    if (other instanceof AbstractQuestion) {
      AbstractQuestion q = (AbstractQuestion) other;
      return q.equalsLikert(this);
    }
    return false;
  }



}
