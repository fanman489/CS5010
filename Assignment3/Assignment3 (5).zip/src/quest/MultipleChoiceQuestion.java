package quest;

import java.util.ArrayList;
import java.util.List;


public class MultipleChoiceQuestion extends AbstractQuestion {

  final private List<String> multipleAnswers = new ArrayList<>();


  MultipleChoiceQuestion (String inputQuestion, String inputCorrectAnswer, String ... answer){

    super(inputQuestion, inputCorrectAnswer);

    for (String i : answer) {
      this.multipleAnswers.add(i);
    }

    this.checkCorrectAnswer();


  }

  @Override
  public String inputAnswer(String input) {
    if (input.length() > 1) {
      return "Incorrect.";
    }

    if (correctAnswer.charAt(0) == input.charAt(0)) {
      return "Correct.";
    } else {
      return "Incorrect.";
    }

  }


  @Override
  public String toString(){

    String output;
    output = this.question;

    for (int i = 0; i < this.multipleAnswers.size(); i++) {
      output = output + " ["  + i + "] " + this.multipleAnswers.get(i);
    }

    return output;

  }


  @Override
  protected boolean equalsMultipleChoice(MultipleChoiceQuestion other){
    return this.toString().compareToIgnoreCase(other.toString()) == 0;
  }


  @Override
  public boolean equals(Object other) {
    if (other instanceof AbstractQuestion) {
      AbstractQuestion q = (AbstractQuestion) other;
      return q.equalsMultipleChoice(this);
    }
    return false;
  }


  private void checkCorrectAnswer(){

    if(multipleAnswers.size() < 3 || multipleAnswers.size() > 8) {
      throw new IllegalArgumentException ("Need to have between 3 to 8 multiple choice answers.");
    }

    if (question.isEmpty() || correctAnswer.isEmpty() || multipleAnswers.isEmpty()) {
      throw new IllegalArgumentException ("Need to input question, multiple choices, and correct answer.");
    }




    if(Character.isDigit(correctAnswer.charAt(0))) {
      if (Character.getNumericValue( correctAnswer.charAt(0)) <= 0 || Character.getNumericValue( correctAnswer.charAt(0)) > multipleAnswers.size()){
        throw new IllegalArgumentException ("Invalid correct answer.");
      }
    } else {
      throw new IllegalArgumentException ("Invalid correct answer.");
    }

  }






}
