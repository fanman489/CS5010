package quest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class QuestionnaireArray implements Questionnaire {

  private List<Question> questionnaireArray =  new ArrayList<Question>();


  QuestionnaireArray(Question... list) throws IllegalArgumentException {

    for (Question i : list) {
      questionnaireArray.add(i);

    }

    for (int i = 0; i < questionnaireArray.size(); i ++){
      for (int j = i+1; j < questionnaireArray.size(); j ++){
        if(questionnaireArray.get(i).equals(questionnaireArray.get(j))) {
          throw new IllegalArgumentException("Cannot input duplicate questions");
        }

      }
    }
  }





  public String toString(){
    Integer size = questionnaireArray.size();
    String output = "";

    for (int i = 0; i < size; i++){
      output = output + (i + 1) + ". " + questionnaireArray.get(i).toString() + " \n";
    }

    return output;

  }

  public void sort(){

    Collections.sort(questionnaireArray, new TextComparator());
    Collections.sort(questionnaireArray, new TypeComparator());

  }




}
