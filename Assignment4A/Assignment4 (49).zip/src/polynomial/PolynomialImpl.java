package polynomial;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * This class represents a specific polynomial.
 */

public class PolynomialImpl implements Polynomial {

  private PolynomialNode head;

  public PolynomialImpl() {
    head = new PolynomialNodeEmpty();
  }

  public PolynomialImpl(PolynomialNode p) {
    head = p;
  }

  public void addTerm(int c, int d) {
    head = head.addTerm(new PolynomialTerm(d, c));
  }

  public int getDegree() {
    return head.getDegree();
  }

  public int getCoefficient(int power) {
    return head.getCoefficient(power);
  }

  public Polynomial derivative() {
    return new PolynomialImpl(this.head.derive());
  }

  @Override
  public String toString() {
    if (head.toString().charAt(0) == '+') {
      return head.toString().substring(1);
    } else {
      return head.toString();
    }
  }

  public double evaluate(Double d) {
    Evo e = new Evo();
    return head.sortAndReduceByPower().evaluate(e, d);

  }



  public Polynomial add(Polynomial p) {

    String s = this.toString();
    String t = p.toString();

    s = s.replaceAll("\\+", " \\+");
    s = s.replaceAll("\\-", " \\-");
    t = t.replaceAll("\\+", " \\+");
    t = t.replaceAll("\\-", " \\-");

    String st = s + " +" + t;

    Polynomial sum = new PolynomialImpl(st);

    return sum;
  }





  public boolean equalPolynomials(Polynomial p) {


    String s = this.toString();
    String t = p.toString();

    s = s.replaceAll("\\+", " \\+");
    s = s.replaceAll("\\-", " \\-");
    t = t.replaceAll("\\+", " \\+");
    t = t.replaceAll("\\-", " \\-");

    Polynomial string1 = new PolynomialImpl(s);
    Polynomial string2 = new PolynomialImpl(t);

    return string1.toString().equals(string2.toString());

  }

  public PolynomialImpl(String input) throws IllegalArgumentException {

    head = new PolynomialNodeEmpty();

    if (input.isEmpty()) {
      throw new IllegalArgumentException("Invalid polynomial." + input);
    }


    Scanner fromStr = new Scanner(input);
    fromStr.useDelimiter(" ");

    String c = "";
    int d = 0;
    int f = 0;


    try {
      while (fromStr.hasNext()) {
        c = fromStr.next();
        Scanner exp = new Scanner(c);
        exp.useDelimiter("X\\^");

        d = exp.nextInt();
        if (exp.hasNextInt()) {
          f = exp.nextInt();
          if (f < 0) {
            throw new IllegalArgumentException("Invalid Polynomial");
          }
        } else {
          f = 0;
        }

        head = head.addTerm(new PolynomialTerm(f, d));
      }
    } catch (InputMismatchException ex) {
      throw new IllegalArgumentException("Invalid Polynomial");
    }



  }


  public static String testScanner(String input) {


    Scanner fromStr = new Scanner(input);
    fromStr.useDelimiter(" ");

    String test = "";
    String c = "";
    int d = 0;
    int f = 0;

    while(fromStr.hasNext()) {
      c = fromStr.next();


      Scanner exp = new Scanner(c);
      exp.useDelimiter("X\\^");

      test = test + exp.nextInt();

    }

    return test;

  }

  public String testing() {
    String s = head.toString();
    s = s.replaceAll("\\+", " \\+");
    s.replaceAll("\\-", " \\-");
    return s;
  }


/*
  public static String testScanner2(String input) {


    Scanner fromStr = new Scanner(input);
    fromStr.useDelimiter("X\\^");

    String test = "";
    String c = "";
    Integer d = 0;
    Integer f = 0;

    while(fromStr.hasNext()) {
      d = fromStr.nextInt();
      f = fromStr.nextInt();


    }

    return Integer.toString(f);

  }




    String exp = fro
    Pattern pattern = Pattern.compile("([+-]?(?:(?:\\d+x\\^\\d+)|(?:\\d+x)|(?:\\d+)|(?:x)))");
    Matcher matcher = pattern.matcher(exp);

    Scanner in = new Scanner(exp);
    in.useDelimiter("([+-]?(?:(?:\\d+x\\^\\d+)|(?:\\d+x)|(?:\\d+)|(?:x)))");
    String y = "";
    while (in.hasNext()) {
      y = y+in.next();
    }
*/
}
