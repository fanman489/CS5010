package polynomial;

import org.junit.Test;

import static org.junit.Assert.*;

public class PolynomialTest {

  Polynomial testList = new PolynomialImpl();

  Polynomial testList2 = new PolynomialImpl();


  @Test
  public void testAddTerm() {


    testList.addTerm(1, 2);
    testList.addTerm(2, 4);
    testList.addTerm(3, 5);
    testList.addTerm(4, 6);
    testList.addTerm(7, 8);


    testList2.addTerm(1,2);
    testList2.addTerm(2,3);
    testList2.addTerm(4,5);
    testList2.addTerm(4,3);
    testList2.addTerm(2,1);


    assertEquals(testList.equals(testList), true);


    Polynomial testListDerive = testList.add(testList2);
    assertEquals(testListDerive.toString(), "");

    assertEquals(testList.toString(), "");


    assertEquals(testList.evaluate(1.0), (Double) 13.0);
    assertEquals(testList.getDegree(), (Integer) 5);
    assertEquals(testList.getCoefficient(2), (Integer) 5);


  }

  @Test
  public void testList() {

    Polynomial x = new PolynomialImpl("3X^2 + 4X^1 + 5");
    assertEquals(x.toString(), "");

  }


  @Test
  public void testList1() {

    String x = PolynomialImpl.testScanner("3X^2 + 4X^1");
    assertEquals(x, "");


  }
}