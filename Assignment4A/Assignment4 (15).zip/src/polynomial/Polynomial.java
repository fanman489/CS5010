package polynomial;

public interface Polynomial {

  void addTerm(Integer c, Integer d);

  Integer getDegree();

  Integer getCoefficient(Integer power);

  double evaluate(double input);

  Polynomial derivative();

  Polynomial add(Polynomial p);

  Integer count();

  Polynomial removeFirstElement();

  boolean equals(Polynomial p);

}
