package polynomial;
import java.util.Scanner;


public class PolynomialImpl implements Polynomial {

  private PolynomialNode head;

  public PolynomialImpl() {
    head = new PolynomialNodeEmpty();
  }

  public PolynomialImpl(PolynomialNode p) {
    head = p;
  }

  public void addTerm(int c, int d) {
    head = head.addTerm(new PolynomialTerm(d, c));
  }

  public int getDegree() {
    return head.getDegree();
  }

  public int getCoefficient(int power) {
    return head.getCoefficient(power);
  }

  public Polynomial derivative() {
    return new PolynomialImpl(this.head.derive());
  }

  @Override
  public String toString() {
    return head.toString();
  }

  public double evaluate(double d) {
    try {
      return head.evaluate(d);
    } catch (RuntimeException ex) {
      return 0;
    }
  }

  public int count() {
    return head.count();
  }

  public Polynomial removeFirstElement() {
    return new PolynomialImpl(this.head.removeFirstElement());
  }

  public Polynomial sortAndReduceByPower() {
    return new PolynomialImpl(this.head.sortAndReduceByPower());
  }



  public Polynomial add(Polynomial p) {
    int d;
    int c;
    Polynomial test = this.sortAndReduceByPower();
    Polynomial input = p.sortAndReduceByPower();


    do {
      d = input.getDegree();
      c = input.getCoefficient(d);

      test.addTerm(c, d);
      input = input.removeFirstElement();
    } while (input.count() > 0);

    return test;
  }


  public boolean equals(Polynomial p) {

    int degree1;
    int degree2;
    int coeff1;
    int coeff2;

    Polynomial test = this;
    Polynomial input = p;

   if (p.count() != this.count()) {
     return false;
   }

   do {
     degree1 = test.getDegree();
     degree2 = input.getDegree();
     coeff1 = test.getCoefficient(degree1);
     coeff2 = input.getCoefficient(degree2);

     if (degree1 != degree2 || coeff1 != coeff2) {
       return false;
     }
     input = input.removeFirstElement();
     test = test.removeFirstElement();

   } while(test.count() > 0);


   return true;
  }

  public PolynomialImpl(String input) {

    head = new PolynomialNodeEmpty();

    if (input.isEmpty()) {
      throw new IllegalArgumentException("Invalid polynomial.");
    }


    Scanner fromStr = new Scanner(input);
    fromStr.useDelimiter(" ");

    String c = "";
    int d = 0;
    int f = 0;

    while(fromStr.hasNext()) {
      c = fromStr.next();
      Scanner exp = new Scanner(c);
      exp.useDelimiter("X\\^");

      d = exp.nextInt();
      if (exp.hasNextInt()) {
        f = exp.nextInt();
      } else {
        f= 0;
      }

      head = head.addTerm(new PolynomialTerm(f, d));
    }



  }


  public static String testScanner(String input) {


    Scanner fromStr = new Scanner(input);
    fromStr.useDelimiter(" ");

    String test = "";
    String c = "";
    int d = 0;
    int f = 0;

    while(fromStr.hasNext()) {
      c = fromStr.next();


      Scanner exp = new Scanner(c);
      exp.useDelimiter("X\\^");

      test = test + exp.nextInt();

    }

    return test;

  }


/*
  public static String testScanner2(String input) {


    Scanner fromStr = new Scanner(input);
    fromStr.useDelimiter("X\\^");

    String test = "";
    String c = "";
    Integer d = 0;
    Integer f = 0;

    while(fromStr.hasNext()) {
      d = fromStr.nextInt();
      f = fromStr.nextInt();


    }

    return Integer.toString(f);

  }




    String exp = fro
    Pattern pattern = Pattern.compile("([+-]?(?:(?:\\d+x\\^\\d+)|(?:\\d+x)|(?:\\d+)|(?:x)))");
    Matcher matcher = pattern.matcher(exp);

    Scanner in = new Scanner(exp);
    in.useDelimiter("([+-]?(?:(?:\\d+x\\^\\d+)|(?:\\d+x)|(?:\\d+)|(?:x)))");
    String y = "";
    while (in.hasNext()) {
      y = y+in.next();
    }
*/
}
