package polynomial;

public interface Polynomial {

  void addTerm(int c, int d);

  int getDegree();

  int getCoefficient(int power);

  double evaluate(double input);

  Polynomial derivative();

  Polynomial add(Polynomial p);

  int count();

  Polynomial removeFirstElement();

  boolean equals(Polynomial p);

  String toString();

}
