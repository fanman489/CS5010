package polynomial;

/**
 * This class represents a node of a polynomial list.
 */
public interface PolynomialNode {

  /**
   * This method will add a term to the list of polynomial nodes. It will add to the position
   * such that the list will stay in decreasing order of it's power. Like terms will be combined.
   * @param p A new polynomial term.
   * @return Returns a new node containing the polynomial that will be added to the list.
   */
  PolynomialNode addTerm(ComparePower comparator, PolynomialTerm insert);

  int getDegree();

  int getCoefficient(int p);

  Double evaluate(Evo e, Double d);

  PolynomialNode derive();

  Integer count();

  String toString();

  PolynomialNode removeNoCoefficient();

}
