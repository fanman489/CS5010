package polynomial;
import java.util.Scanner;

public class PolynomialImpl implements Polynomial {

  private PolynomialNode head;

  public PolynomialImpl() {
    head = new PolynomialNodeEmpty();
  }

  public PolynomialImpl(PolynomialNode p) {
    head = p;
  }


  public void addTerm(Integer c, Integer d) {
    head = head.addTerm(new PolynomialTerm(d, c));
  }

  public Integer getDegree() {
    return head.getDegree();
  }

  public Integer getCoefficient(Integer power) {
    return head.getCoefficient(power);
  }


  public Polynomial derivative() {
    return new PolynomialImpl(this.head.derive());
  }

  public String toString() {
    return head.toString();
  }

  public Double evaluate(Double d) {
    return head.evaluate(d);
  }

  public Integer count() {
    return head.count();
  }

  public Polynomial removeFirstElement() {
    return new PolynomialImpl(this.head.removeFirstElement());
  }


  public Polynomial add(Polynomial p) {
    Integer d;
    Integer c;
    Polynomial test = this;
    Polynomial input = p;

    do {
      d = input.getDegree();
      c = input.getCoefficient(d);

      test.addTerm(c, d);
      input = input.removeFirstElement();
    } while (input.count() > 0);

    return test;
  }


  public boolean equals(Polynomial p) {

    Integer degree1;
    Integer degree2;
    Integer coeff1;
    Integer coeff2;

    Polynomial test = this;
    Polynomial input = p;

   if (p.count() != this.count()) {
     return false;
   }

   do {
     degree1 = test.getDegree();
     degree2 = input.getDegree();
     coeff1 = test.getCoefficient(degree1);
     coeff2 = input.getCoefficient(degree2);

     if (degree1 != degree2 || coeff1 != coeff2) {
       return false;
     }
     input = input.removeFirstElement();
     test = test.removeFirstElement();

   } while(test.count() > 0);


   return true;
  }

  public PolynomialImpl(String input) {

    head = new PolynomialNodeEmpty();

    if (input.isEmpty()) {
      return;
    }

    Scanner fromStr = new Scanner(input);
    fromStr.useDelimiter("[^0-9]+");

    String d;
    String c;

    do {
      c = fromStr.next();

      if (fromStr.hasNext()) {
        d = fromStr.next();
      } else {
        d = "0";
      }

      head = head.addTerm(new PolynomialTerm(Integer.parseInt(d), Integer.parseInt(c)));
    } while(fromStr.hasNext());



  }


}
