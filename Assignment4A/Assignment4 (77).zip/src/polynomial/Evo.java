package polynomial;

import java.util.function.ToDoubleBiFunction;

public class Evo implements ToDoubleBiFunction<PolynomialTerm, Double> {

  public double applyAsDouble(PolynomialTerm p, Double d) {

    double j = 1.0;
    for (int i = 0; i < p.getPower(); i++) {
      j = j * d;
    }

    return p.getCoefficient() * j;

  }

}
