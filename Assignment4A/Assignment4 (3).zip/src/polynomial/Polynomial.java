package polynomial;

public interface Polynomial {

  void addTerm(PolynomialTerm p);

  Integer getDegree();

  Integer getCoefficient(Integer power);

  Double evaluate(Double input);

  Polynomial derive();

  Polynomial add(Polynomial p);

  Integer count();

  Polynomial removeFirstElement();

}
