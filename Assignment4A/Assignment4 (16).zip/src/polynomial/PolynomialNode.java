package polynomial;

public interface PolynomialNode {

  PolynomialNode addBack(PolynomialTerm p);

  PolynomialNode addFront(PolynomialTerm p);

  PolynomialNode addTerm(PolynomialTerm p);

  Integer getDegree();

  Integer getCoefficient(Integer p);

  double evaluate(double d);

  PolynomialNode derive();

  Integer count();

  PolynomialNode removeFirstElement();
}
