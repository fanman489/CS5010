package polynomial;

public class MapPolynomials {


}
