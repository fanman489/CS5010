package polynomial;

public class PolynomialImpl implements Polynomial {

  private PolynomialNode head;

  public PolynomialImpl() {
    head = new PolynomialNodeEmpty();
  }

  public PolynomialImpl(PolynomialNode p) {
    head = p;
  }


  public void addTerm(PolynomialTerm p) {
    head = head.addTerm(p);
  }

  public Integer getDegree() {
    return head.getDegree();
  }

  public Integer getCoefficient(Integer power) {
    return head.getCoefficient(power);
  }


  public Polynomial derive() {
    return new PolynomialImpl(this.head.derive());
  }

  public String toString() {
    return head.toString();
  }

  public Double evaluate(Double d) {
    return head.evaluate(d);
  }

  public Integer count() {
    return head.count();
  }

  public Polynomial removeFirstElement() {
    return new PolynomialImpl(this.head.removeFirstElement());
  }


  public Polynomial add(Polynomial p) {
    Integer d;
    Integer c;
    Polynomial test = this;
    Polynomial input = p;

    do {
      d = input.getDegree();
      c = input.getCoefficient(d);

      test.addTerm(new PolynomialTerm(d, c));
      input = input.removeFirstElement();
    } while (input.count() > 0);

    return test;
  }

}
