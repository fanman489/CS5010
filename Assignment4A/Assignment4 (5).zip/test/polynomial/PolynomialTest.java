package polynomial;

import org.junit.Test;

import static org.junit.Assert.*;

public class PolynomialTest {

  Polynomial testList = new PolynomialImpl();

  PolynomialTerm p = new PolynomialTerm(1, 2);
  PolynomialTerm q = new PolynomialTerm(2, 4);
  PolynomialTerm r = new PolynomialTerm(5, 1);
  PolynomialTerm s = new PolynomialTerm(2, 3);
  PolynomialTerm t = new PolynomialTerm(3, 3);

  Polynomial testList2 = new PolynomialImpl();

  PolynomialTerm u = new PolynomialTerm(7, 1);
  PolynomialTerm v = new PolynomialTerm(3, 2);
  PolynomialTerm w = new PolynomialTerm(4, 1);



  @Test
  public void testAddTerm() {


    testList.addTerm(p);
    testList.addTerm(q);
    testList.addTerm(r);
    testList.addTerm(s);
    testList.addTerm(t);


    testList2.addTerm(u);
    testList2.addTerm(v);
    testList2.addTerm(w);
    testList2.addTerm(w);
    testList2.addTerm(w);


    assertEquals(testList.equals(testList), true);


    Polynomial testListDerive = testList.add(testList2);
    assertEquals(testListDerive.toString(), "");

    assertEquals(testList.toString(), "");


    assertEquals(testList.evaluate(1.0), (Double) 13.0);
    assertEquals(testList.getDegree(), (Integer) 5);
    assertEquals(testList.getCoefficient(2), (Integer) 5);


  }

  @Test
  public void testList() {

    assertEquals(PolynomialImpl.testScanner("3X^2+4X^1"), "3");


  }
}