package polynomial;

public interface PolynomialNode {

  PolynomialNode addBack(PolynomialTerm p);

  PolynomialNode addFront(PolynomialTerm p);

  PolynomialNode addTerm(PolynomialTerm p);

  Integer getDegree();

  Integer getCoefficient(Integer p);

  Double evaluate(Double d);

  PolynomialNode derive();

  Integer count();

  PolynomialNode removeFirstElement();
}
