package polynomial;

public interface PolynomialNode {

  PolynomialNode addBack(PolynomialTerm p);

  PolynomialNode addFront(PolynomialTerm p);

  PolynomialNode addTerm(PolynomialTerm p);

  int getDegree();

  int getCoefficient(int p);

  double evaluate(double d);

  PolynomialNode derive();

  Integer count();

  PolynomialNode removeFirstElement();

  String toString();
}
