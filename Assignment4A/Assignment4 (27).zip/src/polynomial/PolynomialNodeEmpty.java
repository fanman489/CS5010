package polynomial;

public class PolynomialNodeEmpty implements PolynomialNode {

  public PolynomialNode addBack(PolynomialTerm p){
    return addFront(p);
  }

  public PolynomialNode addFront(PolynomialTerm p) {
    return new PolynomialNodeElement(p, this);
  };

  public PolynomialNode addTerm(PolynomialTerm p) {
    return addFront(p);
  }

  @Override
  public String toString() {
    return "0";
  }

  public PolynomialNode sortAndReduceByPower() {
    return this;
  }

  public int getDegree() {
    return 0;
  }


  public int getCoefficient(int p) throws IllegalArgumentException {
    return 0;
    //throw new IllegalArgumentException("There is no term with this coefficient. Power:" + Integer.toString(p));
  }

  public double evaluate(double d) {
    return 0;
  }

  public PolynomialNode derive() {
    return this;
  }


  public Integer count() {
    return 0;
  }

  public PolynomialNode removeFirstElement() {
    return this;
  }



}
