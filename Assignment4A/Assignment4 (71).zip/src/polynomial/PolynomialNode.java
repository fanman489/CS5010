package polynomial;

import java.util.function.Function;

public interface PolynomialNode {

  PolynomialNode addFront(PolynomialTerm p);

  PolynomialNode addTerm(PolynomialTerm p);

  int getDegree();

  int getCoefficient(int p);

  Double evaluate(Evo e, Double d);

  PolynomialNode derive();

  Integer count();

  PolynomialNode removeFirstElement();

  PolynomialNode sortAndReduceByPower();

  boolean checkSorted();

  String toString();

  PolynomialNode copy();

  PolynomialNode map(Function<PolynomialNode, PolynomialTerm> converter);

}
