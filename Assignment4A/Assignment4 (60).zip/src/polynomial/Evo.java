package polynomial;

import java.util.function.ToDoubleBiFunction;

public class Evo implements ToDoubleBiFunction<PolynomialTerm, Double> {

  public double applyAsDouble(PolynomialTerm p, Double d) {
    return p.getCoefficient() * Math.pow(d, p.getPower());

  }

}
