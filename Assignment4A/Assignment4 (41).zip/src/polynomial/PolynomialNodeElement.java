package polynomial;

public class PolynomialNodeElement implements PolynomialNode {

  private PolynomialTerm polynomial;
  private PolynomialNode rest;

  public PolynomialNodeElement(PolynomialTerm p, PolynomialNode n) {
    polynomial = p;
    rest = n;
  }


  public PolynomialNode addFront(PolynomialTerm polynomial) {
    return new PolynomialNodeElement(polynomial, this);
  }

  public PolynomialNode addBack(PolynomialTerm polynomial) {
    this.rest = this.rest.addBack(polynomial);
    return this;
  }


  //Is it ok to mutate in this case when the power of the elements are the same
  public PolynomialNode addTerm(PolynomialTerm insert) {

    int power = insert.getPower();

    if (this.polynomial.getPower() > power) {
      return new PolynomialNodeElement(this.polynomial, this.rest.addTerm(insert));
    } else if (this.polynomial.getPower() < power) {
      return new PolynomialNodeElement(insert, this);

    } else {
      this.polynomial.add(insert);
      return this;
    }

  }

  @Override
  public String toString() {
    if (this.rest.toString() == "0") {
      if (this.polynomial.getCoefficient() < 0) {
        return this.polynomial.toString();
      } else {
        return "+" + this.polynomial.toString();
      }
    } else if (this.polynomial.getCoefficient() < 0) {
      return this.polynomial.toString() + this.rest.toString();
    } else {
      return "+" + this.polynomial.toString() + this.rest.toString();
    }
  }

  public int getDegree() {
    return this.polynomial.getPower();
  }

  public int getCoefficient(int p) {
    if (polynomial.getPower() == p ) {
      return this.polynomial.getCoefficient();
    } else {
      return this.rest.getCoefficient(p);
    }
  }


  public double evaluate(double d) {
    return this.polynomial.evaluate(d) + this.rest.evaluate(d);
  }

  public PolynomialNode derive() {
    return new PolynomialNodeElement(this.polynomial.derive(), this.rest.derive());
  }

  public Integer count() {
    return (1 + this.rest.count());
  }



  public PolynomialNode removeFirstElement() {
    return this.rest;
  }


  public PolynomialNode sortAndReduceByPower() {
    return this.rest.addTerm(this.polynomial);
  }


  public PolynomialNode copy() {
    PolynomialNode newNode = new PolynomialNodeElement(
            new PolynomialTerm(this.polynomial.getPower(),
                    this.polynomial.getCoefficient()), this.rest.copy());
    return newNode;
  }

}





