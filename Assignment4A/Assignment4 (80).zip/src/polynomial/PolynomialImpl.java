package polynomial;

import java.util.InputMismatchException;

import java.util.Scanner;
import java.util.function.Function;

/**
 * This class represents a specific polynomial.
 */

public class PolynomialImpl implements Polynomial {

  private PolynomialNode head;

  /**
   * Creates a blank polynomial.
   */
  public PolynomialImpl() {
    head = new PolynomialNodeEmpty();
  }

  /**
   * Creates a polynomial starting at a specific term of the polynomial.
   * @param p A polynomial term that will become the start of a new polynomial.
   */
  private PolynomialImpl(PolynomialNode p) {
    head = p;
  }

  /**
   * Add a term to the polynomial. The new term takes the coefficient and power from the input. If
   * the polynomial already has a term with the same degree, the coefficients will be added
   * together.
   * @param coefficient The coefficient of the polynomial.
   * @param degree The power of the polynomial.
   * @throws IllegalArgumentException Will throw exception if the power is negative.
   */
  public void addTerm(int coefficient, int degree) throws IllegalArgumentException {
    if (degree < 0) {
      throw new IllegalArgumentException("Invalid degree.");
    }
    head = head.addTerm(new PolynomialTerm(degree, coefficient));
  }


  /**
   * Get the highest degree of this polynomial.
   * @return Returns the degree as an integer.
   */
  public int getDegree() {
    return head.getDegree();
  }


  /**
   * Returns the coefficient of the given power.
   * @param power Gets the power that you want the coeffienct of.
   * @return Returns the coefficient of the term.
   */
  public int getCoefficient(int power) {
    return head.getCoefficient(power);
  }


  /**
   * Takes the derivative of the polynomial.
   * @return Returns the result of the derivative.
   */
  public Polynomial derivative() {
    return new PolynomialImpl(this.head.derive());
  }


  /**
   * Outputs the polynomial as a string.
   * @return Polynomial as a string.
   */
  @Override
  public String toString() {
    String concact = "";
    if (head.toString().charAt(0) == '+') {
      concact = head.toString().substring(1);
    } else {
      concact = head.toString();
    }

    concact = concact.replaceAll("\\+\\-", "-");
    concact = concact.substring(0, concact.length() - 2);
    return concact;

  }


  /**
   * Calculates the parameter given the number for x.
   * @param digit Evaluate the function using this double.
   * @return Returns the result of the function.
   */
  public double evaluate(Double digit) {
    Evo e = new Evo();
    head = head.sortAndReduceByPower();
    return head.evaluate(e, digit);
  }


  /**
   * Adds two polynomials together.
   * @param p The polynomial to add.
   * @return Returns the sum of the two polynomials.
   */
  public Polynomial add(Polynomial p) {


    String s = this.toString();
    String t = p.toString();

    s = s.replaceAll("\\+", " \\+");
    s = s.replaceAll("\\-", " \\-");
    t = t.replaceAll("\\+", " \\+");
    t = t.replaceAll("\\-", " \\-");

    String st = s + " +" + t;

    Polynomial newPoly = new PolynomialImpl(st);

    return newPoly;
  }

  @Override
  public boolean equals(Polynomial p) {

    String s = this.toString();
    String t = p.toString();

    s = s.replaceAll("\\+", " \\+");
    s = s.replaceAll("\\-", " \\-");
    t = t.replaceAll("\\+", " \\+");
    t = t.replaceAll("\\-", " \\-");

    return s.equals(t);
  }

  /**
   * This creates a polynomial based on a string input of a polynomial. The string must have the
   * terms separated by a single space.
   */
  public PolynomialImpl(String input) throws IllegalArgumentException {

    head = new PolynomialNodeEmpty();

    if (input.isEmpty()) {
      throw new IllegalArgumentException("Invalid polynomial." + input);
    }

    Scanner fromStr = new Scanner(input);
    fromStr.useDelimiter(" ");

    String c = "";
    int d = 0;
    int f = 0;
    String temp1;
    String temp2;

      while (fromStr.hasNext()) {
        c = fromStr.next();
        Scanner exp = new Scanner(c);
        exp.useDelimiter("x\\^");

        temp1 = exp.next();
        d = checkInteger(temp1, input);


        if (exp.hasNext()) {
          temp2 = exp.next();
          f = checkInteger(temp2, input);
        } else {
          f = 0;
        }

        if (f < 0) {
          throw new IllegalArgumentException("Invalid Polynomial:" + input );
        }

        head = head.addFront(new PolynomialTerm(f, d));
        head = head.sortAndReduceByPower();
      }

  }

  private int checkInteger(String s, String input) throws IllegalArgumentException {
    if (!s.matches("[+-]?\\d+")) {
      throw new IllegalArgumentException("Invalid Polynomial:" + input);
    }

    return Integer.parseInt(s);
  }


  /*
  public static String testScanner(String input) {

    Scanner fromStr = new Scanner(input);
    fromStr.useDelimiter(" ");

    String test = "";
    String c = "";
    int d = 0;
    int f = 0;

    while(fromStr.hasNext()) {
      c = fromStr.next();

      Scanner exp = new Scanner(c);
      exp.useDelimiter("x\\^");

      test = test + exp.nextInt();
    }

    return test;

  }


  */
  /*
  public String testing() {
    String s = head.toString();
    s = s.replaceAll("\\+", " \\+");
    s.replaceAll("\\-", " \\-");
    return s;
  }

  */

  /*
  public static String testScanner2(String input) {


    Scanner fromStr = new Scanner(input);
    fromStr.useDelimiter("x\\^");


    String test = "";
    String c = "";
    String d = "";
    String f = "";

    if (fromStr.next().matches("[+-]?\\d+")){
      d = fromStr.next();
    }

    return d;

  }
  */


  /*



    String exp = fro
    Pattern pattern = Pattern.compile("([+-]?(?:(?:\\d+x\\^\\d+)|(?:\\d+x)|(?:\\d+)|(?:x)))");
    Matcher matcher = pattern.matcher(exp);

    Scanner in = new Scanner(exp);
    in.useDelimiter("([+-]?(?:(?:\\d+x\\^\\d+)|(?:\\d+x)|(?:\\d+)|(?:x)))");
    String y = "";
    while (in.hasNext()) {
      y = y+in.next();
    }

    */

}
