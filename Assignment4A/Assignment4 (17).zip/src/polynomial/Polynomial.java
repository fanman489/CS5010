package polynomial;

public interface Polynomial {

  void addTerm(int c, int d);

  Integer getDegree();

  Integer getCoefficient(int power);

  double evaluate(double input);

  Polynomial derivative();

  Polynomial add(Polynomial p);

  Integer count();

  Polynomial removeFirstElement();

  boolean equals(Polynomial p);

  String toString();

}
