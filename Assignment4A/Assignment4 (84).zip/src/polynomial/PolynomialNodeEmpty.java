package polynomial;

/**
 * Represents an empty node of the polynomial list. This represents the end of the list.
 */

public class PolynomialNodeEmpty implements PolynomialNode {


  /**
   * Adding a new term to the empty node.
   * @param p New polynomial term.
   * @return Returns a new node ahead of the empty node.
   */

  public PolynomialNode addTerm(PolynomialTerm p) {
    return new PolynomialNodeElement(p, this);
  }

  @Override
  public String toString() {
    return "0";
  }


  public int getDegree() {
    return 0;
  }


  public int getCoefficient(int p) throws IllegalArgumentException {
    return 0;

  }

  public Double evaluate(Evo e, Double d) {
    return 0.0;
  }

  public PolynomialNode derive() {
    return this;
  }


  public Integer count() {
    return 0;
  }


  public PolynomialNode removeNoCoefficient() {
    return this;
  }



}
