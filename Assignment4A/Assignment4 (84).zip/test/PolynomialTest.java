import polynomial.Polynomial;

import polynomial.PolynomialImpl;


import org.junit.Test;

import org.junit.Assert;

import static org.junit.Assert.assertEquals;

public class PolynomialTest {

  Polynomial testList = new PolynomialImpl();
  Polynomial testList2 = new PolynomialImpl();

  @Test
  public void testAddTerm() {

    assertEquals("0", testList.toString());

    testList.addTerm(1, 1);

    assertEquals("1x^1", testList.toString());
    testList.addTerm(2, 2);
    testList.addTerm(3, 3);
    testList.addTerm(4, 4);
    testList.addTerm(1, 7);

    assertEquals("1x^7+4x^4+3x^3+2x^2+1x^1", testList.toString());

    testList2.addTerm(1,0);
    assertEquals("1", testList2.toString());
    testList2.addTerm(-2,2);
    assertEquals("-2x^2+1", testList2.toString());
    testList2.addTerm(4,4);
    assertEquals("4x^4-2x^2+1", testList2.toString());
    testList2.addTerm(4,4);
    assertEquals("8x^4-2x^2+1", testList2.toString());
    testList2.addTerm(2,0);
    assertEquals("8x^4-2x^2+3", testList2.toString());


    Polynomial test = new PolynomialImpl();

    assertEquals(test.toString(), "0");

    test.addTerm(1, 1);
    test.addTerm(2, 2);
    test.addTerm(3, 3);
    test.addTerm(2010101010, 7);
    test.addTerm(7, 7);
    test.addTerm(3, 0);


    try {
      test.addTerm(2010101010, 7);
      Assert.fail();
    } catch (ArithmeticException ex) {
      assertEquals("Coefficient out of bounds.", ex.getMessage());
    }



  }

  @Test
  public void testConstructUsingString() {

    Polynomial x = new PolynomialImpl("3x^2 +3x^3 -2x^1 -5");
    assertEquals("3x^3+3x^2-2x^1-5", x.toString());

    Polynomial h = new PolynomialImpl("3x^2 +3x^3 -2x^1 -5 +4x^2");
    assertEquals("3x^3+7x^2-2x^1-5", h.toString());


    try {
      Polynomial z = new PolynomialImpl("2x^2 +6x^1-5");
      Assert.fail();
    } catch (IllegalArgumentException ex) {
      assertEquals("Invalid Polynomial.", ex.getMessage());
    }

    try {
      Polynomial z = new PolynomialImpl("2x^2 +6x^-1 -5");
      Assert.fail();
    } catch (IllegalArgumentException ex) {
      assertEquals("Invalid Polynomial.", ex.getMessage());
    }

    try {
      Polynomial z = new PolynomialImpl("2x^2 +6x^e -5");
      Assert.fail();
    } catch (IllegalArgumentException ex) {
      assertEquals("Invalid Polynomial.", ex.getMessage());
    }

  }




  @Test
  public void testGetDegree() {

    assertEquals(0, testList.getCoefficient(1));

    testList.addTerm(1, 1);
    testList.addTerm(2, 2);
    testList.addTerm(3, 3);
    testList.addTerm(4, 4);
    testList.addTerm(7, 7);
    testList.addTerm(3, 0);
    testList.addTerm(-5, 0);

    assertEquals(7, testList.getCoefficient(7));
    assertEquals(1, testList.getCoefficient(1));
    assertEquals(2, testList.getCoefficient(2));
    assertEquals(-2, testList.getCoefficient(0));
    assertEquals(0, testList.getCoefficient(5));


  }



  @Test
  public void testEvaluateShort() {

    Polynomial test = new PolynomialImpl();

    assertEquals(test.evaluate(2.0), 0, 0.001);

    test.addTerm(1, 1);

    assertEquals(test.evaluate(2.0), 2.0, 0.001);
    test.addTerm(2, 2);
    test.addTerm(-3, 3);
    test.addTerm(-4, 4);
    test.addTerm(7, 7);
    test.addTerm(3, 0);

    assertEquals(test.evaluate(2.0), 821.0, 0.001);

    test.addTerm(5, 20430);

    assertEquals(Double.isInfinite(test.evaluate(10.0)), true);

  }


  @Test
  public void testDerivative() {

    Polynomial test = new PolynomialImpl();

    test.addTerm(1, 1);
    test.addTerm(2, 3);
    test.addTerm(3, 3);
    test.addTerm(2, 3);
    test.addTerm(7, 7);
    test.addTerm(3, 0);

    assertEquals(test.toString(), "7x^7+7x^3+1x^1+3");
    assertEquals(test.derivative(), "49x^6+21x^2+1");

  }


  @Test
  public void testGetCoefficient() {

    Polynomial test = new PolynomialImpl();

    test.addTerm(1, 1);
    test.addTerm(2, 3);
    test.addTerm(3, 3);
    test.addTerm(2, 3);
    test.addTerm(3, 0);
    test.addTerm(3, 0);

    //assertEquals(test.toString(), 0);
    assertEquals(test.toString(), "7x^3+1x^1+6");
    assertEquals(test.getCoefficient(0), 0);

  }


  @Test
  public void testStringPolynomialCreation() {

    Polynomial x = new PolynomialImpl("3x^3 +3x^2 -5 -2x^1");
    assertEquals(x.toString(), "3x^3+3x^2-2x^1-5");

    //Polynomial h = new PolynomialImpl("3x^3 +3x^2 -5 -72");
    //assertEquals(h.toString(), "3x^3+3x^2-2x^1-5");

    Polynomial j = new PolynomialImpl("-6x^195 +184x^189 -68x^187 +130x^182 -116x^181 +50x^178 +90x^177 -89x^176 +82x^175 +14x^172 -9x^168 -93x^165 -39x^163 -28x^160 -78x^158 +38x^157 -51x^156 -73x^154 -19x^153 -156x^152 -26x^151 +27x^149 -45x^148 -93x^145 +58x^144 +87x^143 +152x^142 -27x^141 +65x^140 -98x^139 -104x^135 -66x^133 +83x^132 -28x^131 -49x^130 -7x^125 -74x^124 +40x^122 +4x^119 +28x^117 +83x^115 -59x^114 +48x^113 -62x^111 -83x^109 +18x^106 -112x^104 -66x^102 -82x^100 -3x^99 -3x^89 -82x^86 +63x^84 +93x^80 -38x^76 +76x^73 +28x^65 +82x^61 +13x^60 -20x^59 -96x^58 +80x^57 -114x^48 +122x^45 -80x^43 +60x^38 -22x^35 -26x^33 +34x^32 +11x^31 -128x^29 +44x^22 -45x^14 -51x^12 +64x^10 -74x^6 -30x^5 -99x^4 -72");

    Polynomial h = new PolynomialImpl("-49x^196 +32x^191 -18x^190 +43x^187 -32x^186 +16x^185 -252x^184 -29x^181 +69x^178 +67x^175 +75x^174 -57x^168 +92x^166 -31x^163 +1x^162 +54x^159 -78x^156 -85x^155 +28x^154 -146x^152 -50x^151 +55x^148 -38x^147 +2x^143 -12x^141 +56x^140 -42x^136 -18x^133 -324x^128 -15x^116 -76x^114 +112x^112 -64x^111 +19x^110 -31x^107 +40x^103 -78x^101 +99x^99 -87x^97 +48x^96 -46x^94 +60x^93 -79x^89 -75x^83 +6x^82 -34x^81 -40x^80 -94x^78 -71x^76 +31x^72 +43x^71 +11x^70 -50x^68 -44x^66 +33x^59 +65x^58 -29x^56 -90x^54 -39x^53 -74x^51 +78x^50 -99x^46 -108x^43 +59x^41 -43x^40 -186x^39 -50x^37 -27x^34 -98x^27 +66x^24 +168x^23 +51x^20 +9x^15 -28x^14 +88x^13 +16x^10 -46x^6 +10");

    Polynomial i = j.add(h);

    assertEquals(i.toString(), "");

    try {
      Polynomial z = new PolynomialImpl("3x^2+4x^1 -2");
      Assert.fail();
    } catch (IllegalArgumentException ex) {
      assertEquals("Invalid Polynomial", ex.getMessage());
    }



    try {
      Polynomial z = new PolynomialImpl("3x^-1 +9x^3 -2x^1 -5");
      Assert.fail();
    } catch (IllegalArgumentException ex) {
      assertEquals("Invalid Polynomial", ex.getMessage());
    }




  }



  @Test
  public void testAddPolynomial() {

    testList.addTerm(1, 1);
    testList.addTerm(2, 3);
    testList.addTerm(3, 3);
    testList.addTerm(2, 3);
    testList.addTerm(3, 0);
    testList.addTerm(3, 0);

    testList2.addTerm(-7, 0);
    testList2.addTerm(4, 1);
    testList2.addTerm(-3, 3);


    assertEquals(testList.toString(), "7x^3+1x^1+6");
    assertEquals(testList2.toString(), "-3x^3+4x^1-7");

    Polynomial sumList = testList.add(testList2);
    assertEquals(sumList.toString(), "");

    assertEquals(testList.toString(), "7x^3+1x^1+6");
    assertEquals(testList2.toString(), "3x^3+5x^2+4x^1");
    assertEquals(sumList.toString(), "10x^3+5x^2+5x^1+6");

    Polynomial sumList2 = testList2.add(testList);

    assertEquals(testList.toString(), "7x^3+1x^1+6");
    assertEquals(testList2.toString(), "3x^3+5x^2+4x^1");
    assertEquals(sumList2.toString(), "10x^3+5x^2+5x^1+6");

  }



  @Test
  public void testAddPolynomialsCoeff0() {

    testList.addTerm(6, 0);
    testList.addTerm(2, 2);
    testList.addTerm(-3, 3);


    testList2.addTerm(-6, 0);
    testList2.addTerm(4, 1);
    testList2.addTerm(3, 3);

    Polynomial sumList = testList.add(testList2);

    assertEquals(testList.toString(), "-3x^3+2x^2+6");
    assertEquals(testList2.toString(), "3x^3+4x^1-6");
    assertEquals(sumList.toString(), "3x^3+4x^1-6");

  }


  @Test
  public void testArithmeticOverflow() {

    testList.addTerm(1, 1);
    testList.addTerm(2029293939, 3);


    testList2.addTerm(2029293939, 3);


    Polynomial sumList = testList.add(testList2);

    assertEquals(testList.toString(), "7X^3+1X^1+6");
    assertEquals(testList2.toString(), "3X^3+5X^2+4X^1");
    assertEquals(sumList.toString(), "10X^3+5X^2+5X^1+6");

    Polynomial sumList2 = testList2.add(testList);

    assertEquals(testList.toString(), "7X^3+1X^1+6");
    assertEquals(testList2.toString(), "3X^3+5X^2+4X^1");
    assertEquals(sumList2.toString(), "10X^3+5X^2+5X^1+6");

  }

  /*
  @Test
  public void testString() {

    testList.addTerm(1, 1);
    testList.addTerm(2, 3);
    testList.addTerm(3, 3);
    testList.addTerm(2, 3);
    testList.addTerm(3, 0);
    testList.addTerm(3, 0);

    testList.testing();

    assertEquals(testList.testing(), "");

  }
  */



  @Test
  public void testEquals() {

    testList.addTerm(1, 1);
    testList.addTerm(2, 3);
    testList.addTerm(3, 3);


    testList2.addTerm(1, 1);
    testList2.addTerm(2, 3);
    testList2.addTerm(3, 3);

    assertEquals(testList.equals(testList2), true);

    testList2.addTerm(3, 0);

    assertEquals(testList.equals(testList2), false);


  }


  @Test
  public void testToString() {

    testList.addTerm(-1, 1);
    testList.addTerm(2, 3);
    testList.addTerm(3, 3);



    assertEquals(testList.toString(), "");

  }








}