package calculator;

import static java.lang.Character.isDigit;

abstract class AbstractCalculator implements Calculator {



  protected static Character checkInput(Character input) {

    if (isDigit(input)) {
      return 'i';
    }

    switch (input) {
      case '=':
        return 'e';
      case '+':
        return 'p';
      case '-':
        return 'm';
      case '*':
        return 'x';
      case 'C':
        return 'c';
      default:
        throw new IllegalArgumentException("Invalid input " + input.toString());

    }

  }



  protected Integer performCalculation(Character operation, Integer firstNumber, Integer secondNumber) {

    switch (operation) {
      case '+':

        if (Integer.MAX_VALUE - secondNumber >= firstNumber) {
          firstNumber = firstNumber + secondNumber;
        } else {
          firstNumber = 0;
        }

        return firstNumber;



      case '-':
        if (Integer.MIN_VALUE + secondNumber <= firstNumber) {
          firstNumber = firstNumber - secondNumber;
        } else {
          firstNumber = 0;
        }
        return firstNumber;



      case '*':
        if (Integer.MIN_VALUE / secondNumber <= firstNumber && Integer.MAX_VALUE / secondNumber >= firstNumber) {
          firstNumber = firstNumber * secondNumber;
        } else {
          firstNumber = 0;
        }

        return firstNumber;



    }

    return firstNumber;

  }



  protected Integer updateNumber(Character inputValue, Integer firstNumber) {

    Integer result = Character.getNumericValue(inputValue);



    if (firstNumber == null){
      firstNumber = result;
    } else {
      if ( ((Integer.MAX_VALUE - result) / 10) >= firstNumber) {
        firstNumber = firstNumber * 10 + result;
      } else {
        throw new RuntimeException ("Input integer is too high");
      }
    }


    return firstNumber;




  }



}
