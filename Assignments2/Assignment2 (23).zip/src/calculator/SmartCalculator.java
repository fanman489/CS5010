package calculator;

import static java.lang.Character.isDigit;

public class SmartCalculator extends AbstractCalculator {


  private Integer firstNumber;
  private Integer secondNumber;
  private Character operator;
  private boolean inMemory = false;
  private Character storedOperator;
  private Integer storedNumber;

  public SmartCalculator() {
    firstNumber = null;
    secondNumber = null;
    operator = null;
    storedOperator = null;
    storedNumber = null;

  }


  public SmartCalculator input(Character inputValue) {

    Character selector = checkInput(inputValue);

    if (selector == 'c'){

      if (firstNumber == null) {
        throw new IllegalArgumentException("Inputs are empty.");
      } else {


        firstNumber = null;
        secondNumber = null;
        operator = null;
        storedOperator = null;
        storedNumber = null;
        inMemory = false;

        return this;

      }
    }


    if (operator == null) {
      if (selector == 'i') {
        updateFirstNumber(inputValue);
      } else {

        if (firstNumber == null) {
          if (selector == 'm') {
            throw new IllegalArgumentException("Cannot input negative number.");
          } else {
            return this;
          }
        }

        if (selector == 'e' ) {
          if (inMemory) {
            secondNumber = storedNumber;
            calculate(storedOperator);
            secondNumber = null;
          }
          return this;
        } else {
          operator = inputValue;
        }
      }


    } else {

      if (selector == 'i') {
        updateSecondNumber(inputValue);
      } else {

        if (secondNumber == null) {
          if (selector == 'e') {

            if(inMemory == false) {
              storedNumber = firstNumber;
              storedOperator = operator;
              inMemory = true;
            }




          } else {
            operator = inputValue;
            storedOperator = inputValue;
            getResult();
            return this;

          }
        }


        if (selector == 'e') {
          if (inMemory) {
            secondNumber = storedNumber;
            calculate(storedOperator);
            secondNumber = null;


          } else {


            storedNumber = secondNumber;
            storedOperator = operator;
            inMemory = true;
            calculate(operator);
            secondNumber = null;
            operator = null;

          }

        } else {
          calculate(operator);
          secondNumber = null;
          operator = inputValue;
          inMemory = false;

        }


      }


    }


    getResult();
    return this;


  }


  public String getResult() {

    if (firstNumber == null) {
      return "";
    }else if (operator == null) {
      return firstNumber.toString();
    } else if (secondNumber == null) {
      if (inMemory) {

        return firstNumber.toString();
      } else {
        return firstNumber.toString() + operator.toString();
      }
    } else {
      return firstNumber.toString() + operator.toString() + secondNumber.toString();
    }

  }







  protected void updateFirstNumber(Character inputValue) {



    firstNumber = updateNumber(inputValue, firstNumber);


  }


  private void updateSecondNumber(Character inputValue) {

    secondNumber = updateNumber(inputValue, secondNumber);

  }

  private void calculate(Character operation) {
    firstNumber = performCalculation(operation, firstNumber, secondNumber);
  }



}




