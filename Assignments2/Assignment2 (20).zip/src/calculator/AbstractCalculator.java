package calculator;

import static java.lang.Character.isDigit;

abstract class AbstractCalculator implements Calculator {



  protected static Character checkInput(Character input) {

    if (isDigit(input)) {
      return 'i';
    }

    switch (input) {
      case '=':
        return 'e';
      case '+':
        return 'p';
      case '-':
        return 'm';
      case '*':
        return 'x';
      case 'C':
        return 'c';
      default:
        throw new IllegalArgumentException("Invalid input " + input.toString());

    }

  }



  protected Integer performCalculation(Character operation, Integer firstNumber, Integer secondNumber) {
    switch (operation) {
      case '+':

        if (Integer.MAX_VALUE - secondNumber >= firstNumber) {
          firstNumber = firstNumber + secondNumber;
        } else {
          firstNumber = 0;
        }

        return firstNumber;



      case '-':
        if (Integer.MIN_VALUE + secondNumber <= firstNumber) {
          firstNumber = firstNumber - secondNumber;
        } else {
          firstNumber = 0;
        }
        return firstNumber;



      case '*':
        if (Integer.MIN_VALUE / secondNumber <= firstNumber && Integer.MAX_VALUE / secondNumber >= firstNumber) {
          firstNumber = firstNumber * secondNumber;
        } else {
          firstNumber = 0;
        }

        return firstNumber;


      default:
        return firstNumber;
    }

  }




}
