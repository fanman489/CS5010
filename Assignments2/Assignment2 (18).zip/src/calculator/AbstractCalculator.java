package calculator;

import static java.lang.Character.isDigit;

abstract class AbstractCalculator implements Calculator {

  protected static Character checkInput(Character input) {

    if (isDigit(input)) {
      return 'i';
    }

    switch (input) {
      case '=':
        return 'e';
      case '+':
        return 'p';
      case '-':
        return 'm';
      case '*':
        return 'x';
      case 'C':
        return 'c';
      default:
        throw new IllegalArgumentException("Invalid input " + input.toString());

    }

  }

}
