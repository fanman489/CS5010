package calculator;

import static java.lang.Character.isDigit;

public class SmartCalculator implements Calculator {


  private Integer firstNumber;
  private Integer secondNumber;
  private Character operator;
  private boolean inMemory = false;
  private Character storedOperator;
  private Integer storedNumber;

  public SmartCalculator() {
    firstNumber = null;
    secondNumber = null;
    operator = null;
    storedOperator = null;
    storedNumber = null;

  }


  public SmartCalculator input(Character inputValue) {

    Character selector = checkInput(inputValue);

    if (selector == 'c'){


      firstNumber = null;
      secondNumber = null;
      operator = null;
      storedOperator = null;
      storedNumber = null;
      inMemory = false;

      return this;
    }


    if (operator == null) {
      if (selector == 'i') {
        updateFirstNumber(inputValue);
      } else {

        if (firstNumber == null) {
          return this;
        }

        if (selector == 'e' ) {
          return this;
        } else {
          operator = inputValue;
        }
      }




    } else {

      if (selector == 'i') {
        updateSecondNumber(inputValue);
      } else {


        if (secondNumber == null) {
          if (selector == 'e') {

            if(inMemory == false) {
              storedNumber = firstNumber;
              storedOperator = operator;
              inMemory = true;


            }




          } else {
            operator = inputValue;
            storedOperator = inputValue;
            getResult();
            return this;

          }
        }


        if (selector == 'e') {
          if (inMemory) {
            secondNumber = storedNumber;
            calculate(storedOperator);


          } else {
            calculate(operator);
            operator = null;
          }

        } else {
          calculate(operator);
          operator = inputValue;
          inMemory = false;

        }


      }


    }


    getResult();
    return this;


  }


  public String getResult() {

    if (firstNumber == null) {
      return "";
    }else if (operator == null) {
      return firstNumber.toString();
    } else if (secondNumber == null) {
      if (inMemory) {

        return firstNumber.toString();
      } else {
        return firstNumber.toString() + operator.toString();
      }
    } else {
      return firstNumber.toString() + operator.toString() + secondNumber.toString();
    }

  }


  //checked
  public Character checkInput(Character input) {

    if (isDigit(input)) {
      return 'i';
    }

    switch (input) {
      case '=':
        return 'e';
      case '+':
        return 'p';
      case '-':
        return 'm';
      case '*':
        return 'x';
      case 'c':
        return 'c';
      default:
        throw new IllegalArgumentException("Invalid input");

    }


  }



  private void updateFirstNumber(Character inputValue) {

    Integer result = Character.getNumericValue(inputValue);


    if (firstNumber == null){
      firstNumber= result;
    } else {
      if ( ((Integer.MAX_VALUE - result) / 10) >= firstNumber) {
        firstNumber = firstNumber * 10 + result;
      } else {
        throw new RuntimeException ("Input integer is too high");
      }
    }

  }

  private void updateSecondNumber(Character inputValue) {

    Integer result = Character.getNumericValue(inputValue);


    if (secondNumber == null){
      secondNumber = result;
    } else {
      if ( (Integer.MAX_VALUE - result) / 10 >= secondNumber) {
        secondNumber = secondNumber * 10 + result;
      } else {
        throw new RuntimeException ("Input integer is too high");
      }
    }

  }

  private void calculate(Character operation) {
    switch (operation) {
      case '+':
        if (Integer.MAX_VALUE - secondNumber >= firstNumber) {
          firstNumber = firstNumber + secondNumber;
        } else {
          firstNumber = 0;
        }
        secondNumber = null;
        break;

      case '-':
        if (Integer.MIN_VALUE + secondNumber <= firstNumber) {
          firstNumber = firstNumber - secondNumber;
        } else {
          firstNumber = 0;
        }
        secondNumber = null;
        break;

      case '*':
        if (Integer.MIN_VALUE / secondNumber <= firstNumber && Integer.MAX_VALUE / secondNumber >= firstNumber) {
          firstNumber = firstNumber * secondNumber;
        } else {
          firstNumber = 0;
        }

        secondNumber = null;
        break;

      case 'c':
        firstNumber = null;
        secondNumber = null;
        operator = null;
        storedOperator = null;
        storedNumber = null;
        break;

    }
  }



}




