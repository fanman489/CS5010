package calculator;

import static java.lang.Character.isDigit;

public class SimpleCalculator implements Calculator {

  private Integer firstNumber;
  private Integer secondNumber;
  private Character operator;


  public SimpleCalculator() {
    firstNumber = null;
    secondNumber = null;
    operator = null;


  }




  public SimpleCalculator input(Character inputValue){



    Character selector = checkInput(inputValue);

    if (selector == 'c'){
      firstNumber = null;
      secondNumber = null;
      operator = null;
      return this;
    }


    if (operator == null) {
      if (selector == 'i') {
        updateFirstNumber(inputValue);
      } else {

        if (firstNumber == null) {
          throw new IllegalArgumentException("Need to input number");
        }

        if (selector == 'e') {
          throw new IllegalArgumentException("Need to input second number");
        } else {
          operator = inputValue;
        }
      }



    } else {

      if (selector == 'i'){
        updateSecondNumber(inputValue);
      } else {


        if (secondNumber == null){
          throw new IllegalArgumentException("Need to input second number");
        }

        if (selector == 'e') {
          calculate(operator);
          operator = null;

        } else {
          calculate (operator);
          operator = inputValue;
        }

      }


    }


    getResult();
    return this;


  }





  public String getResult(){

    if (firstNumber == null){
      return "";
    }
    if (operator == null) {
      return firstNumber.toString();
    } else if (secondNumber == null) {
      return firstNumber.toString() + operator.toString();
    } else {
      return firstNumber.toString() + operator.toString() + secondNumber.toString();
    }

  }



  //checked
  private Character checkInput(Character input) {

    if (isDigit(input)) {
      return 'i';
    }

    switch (input) {
      case '=':
        return 'e';
      case '+':
        return 'p';
      case '-':
        return 'm';
      case '*':
        return 'x';
      case 'c':
        return 'c';
      default:
        throw new IllegalArgumentException("Invalid input");

    }

  }



  protected void updateFirstNumber(Character inputValue) {

    Integer result = Character.getNumericValue(inputValue);


    if (firstNumber == null){
      firstNumber = result;
    } else {
      if ( ((Integer.MAX_VALUE - result) / 10) >= firstNumber) {
        firstNumber = firstNumber * 10 + result;
      } else {
        throw new RuntimeException ("Input integer is too high");
      }
    }

  }


  private void updateSecondNumber(Character inputValue) {

    Integer result = Character.getNumericValue(inputValue);


    if (secondNumber == null){
      secondNumber = result;
    } else {
      if ( (Integer.MAX_VALUE - result) / 10 >= secondNumber) {
        secondNumber = secondNumber * 10 + result;
      } else {
        throw new RuntimeException ("Input integer is too high");
      }
    }

  }



  private void calculate(Character operation){
    switch (operation){
      case '+':
        if (Integer.MAX_VALUE - secondNumber >= firstNumber) {
          firstNumber = firstNumber + secondNumber;
        } else {
          firstNumber = 0;
        }
        secondNumber = null;
        break;

      case '-':
        if (Integer.MIN_VALUE + secondNumber <= firstNumber) {
          firstNumber = firstNumber - secondNumber;
        } else {
          firstNumber = 0;
        }
        secondNumber = null;
        break;

      case '*':
        if (Integer.MIN_VALUE / secondNumber <= firstNumber && Integer.MAX_VALUE / secondNumber >= firstNumber) {
          firstNumber = firstNumber * secondNumber;
        } else {
          firstNumber = 0;
        }

        secondNumber = null;
        break;



    }
  }






}