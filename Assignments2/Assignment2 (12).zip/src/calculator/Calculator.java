package calculator;

public interface Calculator {

  Calculator input(Character input);

  String getResult();




}
