package calculator;


/**
 * This class represents a simple calculator. Inputs require operand, operator, operand.
 * It handles addition, subtraction, and multiplication. Inputs cannot be negative, but calculated
 * outputs can be negative.
 * This calculator cannot infer missing operators or operands.
 */
public class SimpleCalculator extends AbstractCalculator {

  private Integer firstNumber;
  private Integer secondNumber;
  private Character operator;


  /**
   * Constructor for the simple calculator.
   */
  public SimpleCalculator() {
    firstNumber = null;
    secondNumber = null;
    operator = null;


  }


  /**
   * Input digits into the calculator one at a time. Inputs must be in the format of operand,
   * operator, operand. Any other order of inputs will result in an error. Negative numbers cannot
   * be input. If the calculated result is too large for the calculator to handle, the result
   * will be 0. If the input operand is too large, you will get an error message. After two
   * operands and an operator have been input, entering another operator will cause the calculator
   * to perform the first operation on the two operands.
   * @param inputValue Input values into the calculator as a character. Inputs can be either
   *                   0 -9 or an operator +, -, *, or =. Entering 'C' will clear all inputs.
   * @return This method returns a SimpleCalculator class object with the inputs updated as
   *         appropriate.
   */

  public SimpleCalculator input(Character inputValue) throws IllegalArgumentException {



    Character selector = checkInput(inputValue);

    if (selector == 'c') {

      if (firstNumber == null) {
        throw new IllegalArgumentException("Inputs already cleared");
      } else {
        firstNumber = null;
        secondNumber = null;
        operator = null;
        return this;
      }
    }


    if (operator == null) {



      if (selector == 'i') {
        updateFirstNumber(inputValue);
      } else {

        if (firstNumber == null) {
          throw new IllegalArgumentException("Need to input number");
        }

        if (selector == 'e') {
          return this;
        } else {
          operator = inputValue;
        }
      }



    } else {

      if (selector == 'i') {
        updateSecondNumber(inputValue);
      } else {

        if (secondNumber == null) {
          throw new IllegalArgumentException("Need to input second number");
        }

        if (selector == 'e') {
          calculate(operator);
          secondNumber = null;
          operator = null;

        } else {
          calculate(operator);
          secondNumber = null;
          operator = inputValue;
        }

      }


    }


    getResult();
    return this;


  }


  /**
   * This method will output the current inputs into the calculator. If you input an operator, the
   * output will show the input. When you input '=' it will display the result. If you have already
   * entered two operands and an operator, upon entering the second operator the calculator
   * will show the result of first operation on the two numbers along with the new operator.
   * @return Outputs the inputs as a string.
   */

  public String getResult() {

    if (firstNumber == null) {
      return "";
    }
    if (operator == null) {
      return firstNumber.toString();
    } else if (secondNumber == null) {
      return firstNumber.toString() + operator.toString();
    } else {
      return firstNumber.toString() + operator.toString() + secondNumber.toString();
    }

  }



  //checked




  //Adds the input digit to the first number.
  private void updateFirstNumber(Character inputValue) {

    firstNumber = updateNumber(inputValue, firstNumber);

  }

  // Adds the input digit to the second number.
  private void updateSecondNumber(Character inputValue) {

    secondNumber = updateNumber(inputValue, secondNumber);

  }


  //Performs the calculation on the two numbers already entered.
  private void calculate(Character operation) {
    firstNumber = performCalculation(operation, firstNumber, secondNumber);
  }








}