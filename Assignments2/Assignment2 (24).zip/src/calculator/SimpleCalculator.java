package calculator;


public class SimpleCalculator extends AbstractCalculator {

  private Integer firstNumber;
  private Integer secondNumber;
  private Character operator;


  public SimpleCalculator() {
    firstNumber = null;
    secondNumber = null;
    operator = null;


  }




  public SimpleCalculator input(Character inputValue) {



    Character selector = checkInput(inputValue);

    if (selector == 'c') {

      if (firstNumber == null) {
        throw new IllegalArgumentException("Inputs already cleared");
      } else {
        firstNumber = null;
        secondNumber = null;
        operator = null;
        return this;
      }
    }


    if (operator == null) {



      if (selector == 'i') {
        updateFirstNumber(inputValue);
      } else {

        if (firstNumber == null) {
          throw new IllegalArgumentException("Need to input number");
        }

        if (selector == 'e') {
          return this;
        } else {
          operator = inputValue;
        }
      }



    } else {

      if (selector == 'i') {
        updateSecondNumber(inputValue);
      } else {

        if (secondNumber == null) {
          throw new IllegalArgumentException("Need to input second number");
        }

        if (selector == 'e') {
          calculate(operator);
          secondNumber = null;
          operator = null;

        } else {
          calculate(operator);
          secondNumber = null;
          operator = inputValue;
        }

      }


    }


    getResult();
    return this;


  }





  public String getResult() {

    if (firstNumber == null) {
      return "";
    }
    if (operator == null) {
      return firstNumber.toString();
    } else if (secondNumber == null) {
      return firstNumber.toString() + operator.toString();
    } else {
      return firstNumber.toString() + operator.toString() + secondNumber.toString();
    }

  }



  //checked




  private void updateFirstNumber(Character inputValue) {



    firstNumber = updateNumber(inputValue, firstNumber);


  }


  private void updateSecondNumber(Character inputValue) {

    secondNumber = updateNumber(inputValue, secondNumber);

  }



  private void calculate(Character operation) {
    firstNumber = performCalculation(operation, firstNumber, secondNumber);
    }








}