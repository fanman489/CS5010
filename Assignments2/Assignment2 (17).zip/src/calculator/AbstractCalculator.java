package calculator;

abstract class AbstractCalculator implements Calculator {



}
