package calculator;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.*;


public class SmartCalculatorTest {


  private SmartCalculator calculator = new SmartCalculator();




  @Test
  public void testInput1() {


    calculator.input('2');
    calculator.input('1');
    calculator.input('+');
    calculator.input('3');
    calculator.input('4');
    calculator.input('-');
    calculator.input('6');
    calculator.input('4');
    calculator.input('*');
    calculator.input('2');
    calculator.input('=');



    Assert.assertEquals( calculator.getResult(), "-18");


  }


  @Test
  public void testInput1j() {


    calculator.input('2');
    calculator.input('1');
    calculator.input('+');
    calculator.input('3');
    calculator.input('4');
    calculator.input('c');



    Assert.assertEquals( calculator.getResult(), "-18");


  }


  @Test
  public void testInput1a() {


    calculator.input('2');
    calculator.input('1');
    calculator.input('4');
    calculator.input('7');
    calculator.input('4');
    calculator.input('8');
    calculator.input('3');
    calculator.input('6');
    calculator.input('4');
    calculator.input('7');





    Assert.assertEquals( calculator.getResult(), "2111111111");


  }


  @Test
  public void testInput1b() {


    calculator.input('2');
    calculator.input('1');
    calculator.input('4');
    calculator.input('7');
    calculator.input('4');
    calculator.input('8');
    calculator.input('3');
    calculator.input('6');
    calculator.input('4');
    calculator.input('8');





    Assert.assertEquals( calculator.getResult(), "2111111111");


  }


  @Test
  public void testInput1c() {

    calculator.input('0');
    calculator.input('+');
    calculator.input('2');
    calculator.input('1');
    calculator.input('4');
    calculator.input('7');
    calculator.input('4');
    calculator.input('8');
    calculator.input('3');
    calculator.input('6');
    calculator.input('4');
    calculator.input('7');





    Assert.assertEquals( calculator.getResult(), "2111111111");


  }


  @Test
  public void testInput1d() {

    calculator.input('0');
    calculator.input('+');
    calculator.input('2');
    calculator.input('1');
    calculator.input('4');
    calculator.input('7');
    calculator.input('4');
    calculator.input('8');
    calculator.input('3');
    calculator.input('6');
    calculator.input('4');
    calculator.input('8');





    Assert.assertEquals( calculator.getResult(), "2111111111");


  }


  @Test
  public void testInput1e() {

    calculator.input('2');
    calculator.input('+');
    calculator.input('2');
    calculator.input('1');
    calculator.input('4');
    calculator.input('7');
    calculator.input('4');
    calculator.input('8');
    calculator.input('3');
    calculator.input('6');
    calculator.input('4');
    calculator.input('7');
    calculator.input('=');





    Assert.assertEquals( calculator.getResult(), "0");


  }


  @Test
  public void testInput1g() {

    calculator.input('0');
    calculator.input('-');
    calculator.input('2');
    calculator.input('1');
    calculator.input('4');
    calculator.input('7');
    calculator.input('4');
    calculator.input('8');
    calculator.input('3');
    calculator.input('6');
    calculator.input('4');
    calculator.input('7');
    calculator.input('-');
    calculator.input('2');
    calculator.input('=');





    Assert.assertEquals( calculator.getResult(), "0");


  }


  @Test
  public void testInput1i() {

    calculator.input('1');
    calculator.input('-');
    calculator.input('2');
    calculator.input('1');
    calculator.input('4');
    calculator.input('7');
    calculator.input('4');
    calculator.input('8');
    calculator.input('3');
    calculator.input('6');
    calculator.input('4');
    calculator.input('7');
    calculator.input('*');
    calculator.input('2');
    calculator.input('=');





    Assert.assertEquals( calculator.getResult(), "0");


  }


  @Test
  public void testInput1h() {


    calculator.input('2');
    calculator.input('1');
    calculator.input('4');
    calculator.input('7');
    calculator.input('4');
    calculator.input('8');
    calculator.input('3');
    calculator.input('6');
    calculator.input('4');
    calculator.input('7');
    calculator.input('*');
    calculator.input('2');
    calculator.input('=');





    Assert.assertEquals( calculator.getResult(), "0");


  }








  @Test
  public void testInput2() {


    calculator.input('2');

    calculator.input('+');

    calculator.input('=');
    calculator.input('=');
    calculator.input('=');
    calculator.input('-');
    calculator.input('+');
    calculator.input('=');







    Assert.assertEquals( calculator.getResult(), "3");


  }

  @Test
  public void testInput2c() {


    calculator.input('2');

    calculator.input('+');

    calculator.input('3');
    calculator.input('-');
    calculator.input('=');









    Assert.assertEquals( calculator.getResult(), "3");


  }








}