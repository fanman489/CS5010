package vehicle;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class RegularManualTransmissionTest3 {

  private RegularManualTransmission car2;

  @Before
  public void setUp1() {
    car2 = new RegularManualTransmission(0,4,2,5,3,6,4,7,4,8);
  }


  @Test
  public void testOutput1a() {
    assertEquals(car2.getStatus(), "OK: everything is OK.");
  }



}