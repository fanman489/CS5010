package vehicle;


/**
 * This class represents a regular car's manual transmission
 */
public class RegularManualTransmission implements ManualTransmission {


  // Attributes to show speed and current gear.
  private int speed = 0;
  private int gear = 1;



  private String status;



  //Attributes used to determine status message.
  private boolean maxGearSpeed;
  private boolean maxGearReached;
  private boolean minGearSpeed;
  private boolean minGearReached;
  private boolean inHigherGearRange;
  private boolean inLowerGearRange;








  private int[] minSpeedRange = new int[5];
  private int[] maxSpeedRange = new int[5];



  private boolean inRangeCheck(int currSpeed, int currGear){

    int gearCount = currGear - 1;

    if (minSpeedRange[gearCount] <= currSpeed & maxSpeedRange[gearCount] >= currSpeed){
      return true;
    }

    return false;

  }


  /**
   * Construct the manual transmission.
   * @param l1
   * @param h1
   * @param l2
   * @param h2
   * @param l3
   * @param h3
   * @param l4
   * @param h4
   * @param l5
   * @param h5
   */
  public RegularManualTransmission( int l1, int h1, int l2, int h2, int l3, int h3, int l4, int h4, int l5, int h5){


  minSpeedRange[0]  = l1;
  minSpeedRange[1]  = l2;
  minSpeedRange[2]  = l3;
  minSpeedRange[3]  = l4;
  minSpeedRange[4]  = l5;

  maxSpeedRange[0]  = h1;
  maxSpeedRange[1]  = h2;
  maxSpeedRange[2]  = h3;
  maxSpeedRange[3]  = h4;
  maxSpeedRange[4]  = h5;


  if ( l1 != 0) {
    throw new IllegalArgumentException("Minimum speed of first gear must be 0");

  }

  for ( int i = 0; i < 5; i++){
    if ( minSpeedRange[i] > maxSpeedRange[i] ) {
      throw new IllegalArgumentException("Minimum speed of gear must be lower than maximum");
    }
  }


    for ( int i = 0; i < 4; i++){
      if ( minSpeedRange[i] > minSpeedRange[i + 1] ) {
        throw new IllegalArgumentException("Minimum of lower gear must be lower than minimum of a higher gear");
      }
    }

    for ( int i = 0; i < 3; i++){
      if ( minSpeedRange[i] > minSpeedRange[i + 2] ) {
        throw new IllegalArgumentException("Gear ranges should not overlap except for adjacent gears");
      }
    }

    for ( int i = 0; i < 4; i++){
      if ( maxSpeedRange[i] > maxSpeedRange[i + 1] ) {
        throw new IllegalArgumentException("Maximum of lower gear must be lower than maximum of a higher gear");
      }
    }

    for ( int i = 0; i < 3; i++){
      if ( maxSpeedRange[i] > maxSpeedRange[i + 2] ) {
        throw new IllegalArgumentException("Gear ranges should not overlap except for adjacent gears");
      }
    }

    for ( int i = 0; i < 4; i++){
      if ( maxSpeedRange[i] < minSpeedRange[i + 1] ) {
        throw new IllegalArgumentException("All speeds must be covered by a gear");
      }
    }




    checkMaxGearSpeed();
    checkMaxGearReached();
    checkMinGearSpeed();
    checkMinGearReached();
    checkInHigherGearRange();
    checkInLowerGearRange();



  }


  public String getStatus() {
    String a;

    a = "The speed is: " + Integer.toString(speed) + " and the gear is: " + Integer.toString(gear);
    return a;
  }

  public int getSpeed(){
    return speed;
  }

  public int getGear(){
    return gear;

  }


  public RegularManualTransmission increaseSpeed(){

    if (maxGearSpeed == false){
      this.setSpeed(speed + 1);
    } else if (maxGearSpeed == true & gear == 5){
      this.setStatus("Cannot increase speed, reached maximum speed");
      return this;
    } else {
      this.setStatus("Cannot increase speed, increase gear first");
      return this;
    }

    checkMaxGearSpeed();
    checkMaxGearReached();
    checkMinGearSpeed();
    checkMinGearReached();
    checkInHigherGearRange();
    checkInLowerGearRange();

    if (inHigherGearRange == true){
      this.setStatus("OK: you may increase the gear.");
    } else {
      this.setStatus("OK: everything is OK.");
    }

    return this;
  }


  public RegularManualTransmission increaseGear(){

    if (maxGearReached == true){
      this.setStatus("Cannot increase gear. Reached maximum gear");
      return this;
    } else if (inHigherGearRange == false) {
      this.setStatus("Cannot increase gear, increase speed first");
      return this;
    } else {
      this.setGear(gear + 1);
      this.setStatus("Ok: everything is OK.");

    }


    checkMaxGearSpeed();
    checkMaxGearReached();
    checkMinGearSpeed();
    checkMinGearReached();
    checkInHigherGearRange();
    checkInLowerGearRange();

    return this;
  }

  public RegularManualTransmission decreaseSpeed(){

    if (minGearSpeed == false){
      this.setSpeed(speed - 1);
    } else if (minGearSpeed == true & gear == 1){
      this.setStatus("Cannot decrease speed, reached minimum speed");
      return this;
    } else {
      this.setStatus("Cannot decrease speed, decrease gear first");
      return this;
    }

    checkMaxGearSpeed();
    checkMaxGearReached();
    checkMinGearSpeed();
    checkMinGearReached();
    checkInHigherGearRange();
    checkInLowerGearRange();

    if (inHigherGearRange == true){
      this.setStatus("OK: you may decrease the gear.");
    } else {
      this.setStatus("OK: everything is OK.");
    }


    checkMaxGearSpeed();
    checkMaxGearReached();
    checkMinGearSpeed();
    checkMinGearReached();
    checkInHigherGearRange();
    checkInLowerGearRange();

    return this;
  }



  public RegularManualTransmission decreaseGear(){

    if (minGearReached == true){
      this.setStatus("Cannot decrease gear. Reached minimum gear");
      return this;
    } else if (inHigherGearRange == false) {
      this.setStatus("Cannot decrease gear, decrease speed first");
      return this;
    } else {
      this.setGear(gear - 1);
      this.setStatus("Ok: everything is OK.");


    }


    return this;

  }







  //All getters and setters.

  private void setSpeed(int speed) {
    this.speed = speed;
  }

  private void setGear(int gear) {
    this.gear = gear;
  }

  private boolean isMaxGearSpeed() {
    return maxGearSpeed;
  }

  private void setMaxGearSpeed(boolean maxGearSpeed) {
    this.maxGearSpeed = maxGearSpeed;
  }

  public boolean isMaxGearReached() {
    return maxGearReached;
  }

  private void setMaxGearReached(boolean maxGearReached) {
    this.maxGearReached = maxGearReached;
  }

  private boolean isMinGearSpeed() {
    return minGearSpeed;
  }

  private void setMinGearSpeed(boolean minGearSpeed) {
    this.minGearSpeed = minGearSpeed;
  }

  private boolean isMinGearReached() {
    return minGearReached;
  }

  private void setMinGearReached(boolean minGearReached) {
    this.minGearReached = minGearReached;
  }

  private boolean isInHigherGearRange() {
    return inHigherGearRange;
  }

  private void setInHigherGearRange(boolean inHigherGearRange) {
    this.inHigherGearRange = inHigherGearRange;
  }

  private boolean isInLowerGearRange() {
    return inLowerGearRange;
  }

  private void setInLowerGearRange(boolean inLowerGearRange) {
    this.inLowerGearRange = inLowerGearRange;
  }

  private int[] getMinSpeedRange() {
    return minSpeedRange;
  }

  private void setMinSpeedRange(int[] minSpeedRange) {
    this.minSpeedRange = minSpeedRange;
  }

  private int[] getMaxSpeedRange() {
    return maxSpeedRange;
  }

  private void setMaxSpeedRange(int[] maxSpeedRange) {
    this.maxSpeedRange = maxSpeedRange;
  }


  private void setStatus(String status) {
    this.status = status;
  }














  //Methods to check class booleans.

  private void checkMaxGearSpeed(){
    int currSpeed = this.speed;
    int currGear = this.gear;

    if (currSpeed == maxSpeedRange[currGear]){
      setMaxGearSpeed(true);
    } else {
      setMaxGearSpeed(false);
    }

  }

  private void checkMinGearSpeed(){
    int currSpeed = this.getSpeed();
    int currGear = this.getGear();

    if (currSpeed == minSpeedRange[currGear]){
      setMinGearSpeed(true);
    } else {
      setMinGearSpeed(false);
    }
  }

  private void checkMinGearReached(){
    if( this.getGear()  == 1){
      setMinGearReached(true);
    } else {
      setMinGearReached(false);
    }
  }

  private void checkMaxGearReached(){
    if( this.getGear()  == 5){
      setMaxGearReached(true);
    } else {
      setMaxGearReached(false);
    }
  }

  private void checkInHigherGearRange(){
    int currSpeed = this.getSpeed();
    int currGear = this.getGear();

    if (inRangeCheck(currSpeed, currGear) & currGear < 5){
      setInHigherGearRange(true);
    } else {
      setInHigherGearRange(false);
    }
  }


  private void checkInLowerGearRange(){
    int currSpeed = this.getSpeed();
    int currGear = this.getGear();

    if (inRangeCheck(currSpeed, currGear) & currGear > 1){
      setInLowerGearRange(true);
    } else {
      setInLowerGearRange(false);
    }
  }


}
