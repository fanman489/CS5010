package vehicle;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class RegularManualTransmissionTest {

  private RegularManualTransmission car;

  @Before
  public void setUp(){
    car = new RegularManualTransmission(0,3,3,5,5,7,7,9,9,11);
  }


  @Test
  public void testOutput(){
    assertEquals(car.getStatus(), "The speed is: 0 and the gear is: 1");
  }





}