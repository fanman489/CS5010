package vehicle;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class RegularManualTransmissionTest2 {

  private RegularManualTransmission car2;

  @Before
  public void setUp1(){
    car2 = new RegularManualTransmission(0,4,0,4,0,4,0,4,0,4);
  }


  @Test
  public void testOutput1a(){
    assertEquals(car2.getStatus(), "OK: everything is OK.");
  }



}