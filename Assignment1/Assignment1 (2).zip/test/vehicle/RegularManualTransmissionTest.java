package vehicle;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class RegularManualTransmissionTest {

  private RegularManualTransmission car;

  @Before
  public void setUp1(){
    car = new RegularManualTransmission(0,4,3,6,5,8,7,10,9,12);
  }


  @Test
  public void testOutput1a(){
    assertEquals(car.getStatus(), "OK: everything is OK.");
  }


  @Test
  public void testOutput1b(){
    assertEquals(car.getSpeed(), 0);
  }



  //Test requirement for lowest speed on first gear is at one

  /*
  @Before
  public void setUp1(){
    car = new RegularManualTransmission(1,3,3,5,5,7,7,9,9,11);
  }


  @Test
  public void testOutput2(){
    assertEquals(car.getStatus(), "The speed is: 0 and the gear is: 1");
  }
  */





  @Test
  public void testOutput2a(){
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseSpeed();
    assertEquals(car.getStatus(), "OK: you may increase the gear.");
  }


  @Test
  public void testOutput2b(){
    car.increaseSpeed();
    assertEquals(car.getSpeed(),  1);
  }

  @Test
  public void testOutput2c(){
    car.increaseSpeed();
    assertEquals(car.getGear(),  1);
  }




  @Test
  public void testOutput2d(){
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseSpeed();
    assertEquals(car.getStatus(), "Cannot increase speed, increase gear first.");
  }


  @Test
  public void testOutput2e(){
    car.increaseSpeed();
    car.increaseGear();

    assertEquals(car.getStatus(), "Cannot increase gear, increase speed first.");
  }

  @Test
  public void testOutput2f(){
    car.increaseSpeed();
    car.increaseGear();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseGear();
    car.decreaseGear();


    assertEquals(car.getGear(), 1);
  }


  @Test
  public void testOutput2g(){
    car.increaseSpeed();
    car.increaseGear();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseGear();

    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseGear();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseGear();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseGear();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseGear();
    car.increaseSpeed();
    car.increaseSpeed();
    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseGear();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseGear();
    car.increaseSpeed();
    car.increaseSpeed();






    assertEquals(car.getGear(), 5);
  }


  @Test
  public void testOutput2h() {
    car.increaseSpeed();
    car.increaseGear();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseGear();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseGear();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseGear();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseGear();
    car.increaseSpeed();


    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseGear();
    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseGear();
    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseGear();
    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseGear();
    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseSpeed();
    car.decreaseGear();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseSpeed();
    car.increaseGear();
    car.decreaseGear();
    car.decreaseSpeed();
    car.decreaseSpeed();



    assertEquals(car.getSpeed(), 1);
  }










}