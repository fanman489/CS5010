package vehicle;

public interface ManualTransmission {

  /**
   * Returns the status of the transmission.
   * @return Returns the status of the transmission as a string.
   */
  public String getStatus();

  /**
   * Gets the current speed of the vehicle.
   * @return Returns the speed of the vehicle as an integer.
   */
  public int getSpeed();

  /**
   * Gets the current gear of the vehicle.
   * @return Returns the speed of the vehicle as an integer.
   */
  public int getGear();



  public ManualTransmission increaseSpeed();
  public ManualTransmission decreaseSpeed();
  public ManualTransmission increaseGear();
  public ManualTransmission decreaseGear();



}
