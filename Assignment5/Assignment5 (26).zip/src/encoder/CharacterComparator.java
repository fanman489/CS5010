package encoder;

import java.util.Comparator;


/**
 *
 */
public class CharacterComparator implements Comparator<CharacterCode> {

  public int compare(CharacterCode a, CharacterCode b) {

    if (a.getFrequency() != b.getFrequency()) {
      return a.getFrequency() - b.getFrequency();
    }
    return a.getCharacters().toString().compareTo(b.getCharacters().toString());
  }
}
