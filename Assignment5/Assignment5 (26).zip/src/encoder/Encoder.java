package encoder;

import decoder.Decoder;

/**
 *
 */
public interface Encoder {

  /**
   *
   * @param message
   * @return
   */
  Decoder createTree(String message);

  /**
   *
   * @param message
   * @return
   */
  String encode(String message);

}
