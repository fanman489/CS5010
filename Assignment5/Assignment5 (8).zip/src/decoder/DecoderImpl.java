package decoder;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DecoderImpl implements Decoder {

  private TreeNode root;
  private List<Character> codeValues = new ArrayList<Character>();

  public DecoderImpl(String allowedCode) {
    root = new GroupNode();
    for (Character c:allowedCode.toCharArray()) {
      codeValues.add(c);
    }
  }

  /**
   * Empty codes will be ignored. Typing in the same code will not overwrite existing codes already
   * in the tree.
   * @param symbol
   * @param code
   */
  public void addCode(char symbol, String code) {

    char searchChar;
    TreeNode current = root;

    List<Character> leafList;
    leafList = root.toList().stream().map(e -> e.getSymbol()).collect(Collectors.toList());
    if (leafList.contains(symbol)) {
      throw new IllegalArgumentException("This symbol already input.");
    }

    for (Character c:code.toCharArray()) {
      if (!codeValues.contains(c)) {
        throw new IllegalStateException("This code is not allowed.");
      }
    }


    //Cycle through the string code, if the code doesnt exist, create a path to it
    for (int i = 0; i < code.length(); i++) {
      searchChar = code.charAt(i);
      TreeNode leaf = current.checkNode(searchChar);

      if (leaf != null) {
        current = leaf;
      } else {
        if (i == code.length() - 1) {
          TreeNode newCode = new LeafNode(symbol, searchChar, code);
          current = current.addLeafs(newCode);

        } else {
          TreeNode newCode = new GroupNode(searchChar);
          current = current.addLeafs(newCode);
        }
      }

    }
  }

  public String allCodes() {
    List<String> leafList = new ArrayList<String>();
    leafList = root.toList().stream().map(e -> e.getCodeNameAndSymbol()).collect(Collectors.toList());
    String output = "";

    for (int i = 0; i < leafList.size(); i++) {
      output = output + leafList.get(i) + "\n";
    }
    return output;
  }


  public String decode(String code) {

    char searchChar;
    StringBuilder tempCode = new StringBuilder("");
    int codeLength = code.length();
    String output = "";

    TreeNode current = root;

    for (int i = 0; i < code.length(); i++) {

      searchChar = code.charAt(i);
      tempCode = tempCode.append(Character.toString(code.charAt(i)));
      TreeNode leaf = current.checkNode(searchChar);

      if (leaf == null) {
        throw new IllegalStateException("No such code exists.");
      }

      if (leaf.getSymbol() != null ) {
        output = output + leaf.getSymbol();
        codeLength = codeLength - i;
        break;
      }

      if (i == code.length() - 1) {
        throw new IllegalStateException("No such code exists.");
      }

      current = leaf;
    }

    if (codeLength > 0) {
      output = output + this.decode(code.substring(tempCode.length()));
    }
    return output;
  }


  public boolean isCodeComplete() {
    int numberOfNodes = root.getLeafs().size();
    return root.checkNumberofNodes(numberOfNodes);
  }





}
