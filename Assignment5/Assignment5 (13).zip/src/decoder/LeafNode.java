package decoder;

import java.util.ArrayList;

import java.util.List;

public class LeafNode extends AbstractNode {

  private char symbol;
  private String codePath;


  public LeafNode(char codedChar, char name, String path) {
    super(name);
    symbol = codedChar;
    codePath = path;

  }

  public TreeNode addLeafs(TreeNode leaf) {

    throw new IllegalArgumentException("Cannot insert.");

  }

  public List<TreeNode> toList() {
    List<TreeNode> result = new ArrayList<TreeNode>();
    result.add(this);
    return result;
  }



  public String getCodeNameAndSymbol() {
    return symbol + ":" + this.codePath;
  }

  @Override
  public Character getSymbol() {
    return symbol;
  }



}
