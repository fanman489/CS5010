package decoder;

import java.util.List;
import java.util.function.Predicate;

public abstract class AbstractNode implements TreeNode {

  private final Character codeName;

  public AbstractNode(Character name) {
    codeName = name;
  }

  public Character getCodeName() {
    return codeName;
  }

  public int countCode(char code) {
    if (this.codeName == code) {
      return 1;
    }
    return 0;
  }


  public String getCodeNameAndSymbol() {
    return null;
  }

  public Character getSymbol() {
    return null;
  }

  public TreeNode checkNode(char check) {
    return null;
  }

  public boolean checkNumberofNodes(int compare) {
    return true;
  }

  public List<TreeNode> getLeafs() {
    return null;
  }



}
