package decoder;

import org.junit.Test;

import org.junit.Assert;

import static org.junit.Assert.assertEquals;

public class DecoderTest {

  Decoder testTree = new DecoderImpl();


  @Test
  public void testAddTreeBase() {

    assertEquals("", testTree.allCodes());

    testTree.addCode('b',"");
    assertEquals("", testTree.allCodes());

    try {
      testTree.addCode('b', null);
      Assert.fail();
    } catch (NullPointerException ex) {
      assertEquals(null, ex.getMessage());
    }


    testTree.addCode('b',"1");
    assertEquals(testTree.allCodes(), "b: 1" + "\n");


    try {
      testTree.addCode('c', "12");
      Assert.fail();
    } catch (IllegalArgumentException ex) {
      assertEquals("Cannot insert.", ex.getMessage());
    }


    //check if there is time
    testTree.addCode('c',"1");
    assertEquals("b: 1" + "\n", testTree.allCodes());


  }



  @Test
  public void testAddMultipleNodes() {

    assertEquals(testTree.allCodes(), "");

    testTree.addCode('b',"1213");
    assertEquals(testTree.allCodes(), "b: 1213\n");
    testTree.addCode('c',"1216");
    assertEquals(testTree.allCodes(), "b: 1213\n" +
            "c: 1216\n");
    testTree.addCode('d',"4311");
    testTree.addCode('-',"abc");
    testTree.addCode('r',"1212");
    testTree.addCode('+',"acb");

    try {
      testTree.addCode('d', "1215");
      Assert.fail();
    } catch (IllegalArgumentException ex) {
      assertEquals("This symbol already input.", ex.getMessage());
    }


    assertEquals(testTree.allCodes(), "b: 1213\n" +
            "c: 1216\n" +
            "r: 1212\n" +
            "d: 4311\n" +
            "-: abc\n" +
            "+: acb\n");

  }


  @Test
  public void testDecodeMultipleChar() {

    try {
      assertEquals(testTree.decode("1"), "");
      Assert.fail();
    } catch (IllegalStateException ex) {
      assertEquals("No such code exists.", ex.getMessage());
    }

    assertEquals(testTree.decode(""), "");

    testTree.addCode('b',"10");
    testTree.addCode('c',"121");
    testTree.addCode('a',"");
    testTree.addCode('-',"132");
    testTree.addCode('e',"2");

    assertEquals(testTree.decode(""), "");
    assertEquals("-", testTree.decode("132"));
    assertEquals("bc-b", testTree.decode("1012113210"));


    try {
      assertEquals(testTree.decode("1321"), "");
      Assert.fail();
    } catch (IllegalStateException ex) {
      assertEquals("No such code exists.", ex.getMessage());
    }

  }


  @Test
  public void testDecodeSingleChar() {


    testTree.addCode('a',"1");
    testTree.addCode('b',"2");
    testTree.addCode('c',"3");
    testTree.addCode('d',"4");
    testTree.addCode('e',"5");

    assertEquals("abcde", testTree.decode("12345"));
    assertEquals("abcbcd", testTree.decode("123234"));

    try {
      assertEquals(testTree.decode("132623"), "");
      Assert.fail();
    } catch (IllegalStateException ex) {
      assertEquals("No such code exists.", ex.getMessage());
    }



  }


  @Test
  public void testTreeCompleteCheck() {

    assertEquals(true, testTree.isCodeComplete());

    testTree.addCode('b',"12");
    assertEquals(true, testTree.isCodeComplete());
    testTree.addCode('c',"11");
    assertEquals(false, testTree.isCodeComplete());
    testTree.addCode('a',"21");
    assertEquals(false, testTree.isCodeComplete());
    testTree.addCode('d',"22");

    //assertEquals(testTree.decode("12110121132"), "");

    assertEquals(true, testTree.isCodeComplete());

  }

}