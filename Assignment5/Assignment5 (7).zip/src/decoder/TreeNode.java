package decoder;

import java.util.List;

public interface TreeNode {

  TreeNode addLeafs(TreeNode leaf);

  Character getCodeName();

  List<TreeNode> toList();

  String getCodeNameAndSymbol();

  TreeNode checkNode(char code);

  Character getSymbol();

  boolean checkNumberofNodes(int compare);

  List<TreeNode> getLeafs();


}
