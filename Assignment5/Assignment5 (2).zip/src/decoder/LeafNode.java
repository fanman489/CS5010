package decoder;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class LeafNode extends AbstractNode {

  private char symbol;


  public LeafNode(char codedChar, String name) {
    super(name);
    symbol = codedChar;

  }

  public TreeNode addLeafs(String parentNode, TreeNode leaf) {



    if (parentNode.equals(this.getCodeName())) {
      throw new IllegalArgumentException("Cannot insert.");
      /*
      GroupNode newGroupNode = new GroupNode(parentNode);
      newGroupNode.addLeafs(parentNode, leaf);
      return newGroupNode;
      */
    }
    return this;

  }

  public List<TreeNode> toList() {
    List<TreeNode> result = new ArrayList<TreeNode>();
    result.add(this);
    return result;
  }



  public String getCodeNameAndSymbol() {

    return "Symbol:" + symbol + "Codename:" + this.getCodeName();
  }



}
