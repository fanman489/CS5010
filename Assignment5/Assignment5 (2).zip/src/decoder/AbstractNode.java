package decoder;

import java.util.function.Predicate;

public abstract class AbstractNode implements TreeNode {

  private final String codeName;

  public AbstractNode(String name) {
    codeName = name;
  }

  public String getCodeName() {
    return codeName;
  }

  public int countCode(String code) {
    if (this.codeName.equals(code)) {
      return 1;
    }
    return 0;
  }


  public String getCodeNameAndSymbol() {
    return null;
  }


}
