package decoder;

import java.util.List;
import java.util.function.Predicate;

public interface TreeNode {

  public TreeNode addLeafs(String parentNode, TreeNode leaf);

  public String getCodeName();

  public List<TreeNode> toList();

  public int countCode(String code);

  public String getCodeNameAndSymbol();
}
