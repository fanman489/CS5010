package decoder;

import java.util.ArrayList;

import java.util.LinkedList;

import java.util.List;

/**
 * This class represents a parent node in the node tree. In addition to the character code, it
 * also has a list of the children.
 */

public class GroupNode extends AbstractNode{

  private List<TreeNode> children;

  /**
   * Constructor for the parent node, which populates the code character and creates an empty
   * list of children.
   * @param name This the code character associated with the node.
   */
  public GroupNode(char name) {
    super(name);
    children = new LinkedList<TreeNode>();
  }

  //Private constructor used in checkNode.
  private GroupNode() {
    super(null);
    children = new LinkedList<TreeNode>();
  }


  /**
   * This method will adds a child node to the selected parent node.
   * @param node This is the child node to add.
   * @throws RuntimeException This will throw an exception if a leaf of the same code
   *          already exists.
   */
  public void addLeafs(TreeNode node) throws RuntimeException {

    if (checkLeafsForAdding(node.getCodeName())) {
      this.children.add(node);
    } else {
      throw new RuntimeException("Cannot add this node." + node.getCodeName() + " " + this.getCodeName());
    }
  }

  //Check if the leaf note we want to add will overwrite a leaf node.
  private boolean checkLeafsForAdding(char nameCheck) {
    for (int i = 0; i< this.children.size(); i++) {
      if(this.children.get(i).getCodeName() == nameCheck && this.children.get(i).getSymbol() != null) {
        return false;
      }
    }

    return true;
  }


  public List<TreeNode> toList() {

    List<TreeNode> result = new ArrayList<TreeNode>();
    for (TreeNode e:children) {
      result.addAll(e.toList());
    }
    return result;
  }


  @Override
  public TreeNode checkNode(char check) {

    if (children != null) {
      for (TreeNode node:children) {
        if (node.getCodeName() == check) {
          return node;
        }
      }
    }
    return null;
  }

  @Override
  public boolean checkNumberofNodes(int compare) {
    int size = children.size();

    if (size - compare != 0) {
      return false;
    }
    for (TreeNode eachLeaf:children) {
      if (!eachLeaf.checkNumberofNodes(compare)) {
        return false;
      }
    }

    return true;
  }


  public List<TreeNode> getLeafs() {
    return children;
  }


}
