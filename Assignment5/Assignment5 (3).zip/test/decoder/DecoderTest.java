package decoder;

import org.junit.Before;
import org.junit.Test;

import org.junit.Assert;

import static org.junit.Assert.assertEquals;

public class DecoderTest {

  Decoder testTree = new DecoderImpl("1");

  @Test
  public void testAddTree() {

    testTree.addCode('b',"10");
    testTree.addCode('c',"121");
    //testTree.addCode('c',"1311");
    testTree.addCode('d',"132");

    assertEquals(testTree.decode("12110121132"), "");

    assertEquals(testTree.allCodes(), "");

  }

}