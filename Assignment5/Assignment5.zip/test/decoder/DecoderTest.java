package decoder;

import org.junit.Before;
import org.junit.Test;

import org.junit.Assert;

import static org.junit.Assert.assertEquals;

public class DecoderTest {

  Decoder testTree = new DecoderImpl("1");

  @Test
  public void testAddTree() {

    testTree.addCode('b',"10");
    testTree.addCode('b',"11");

    assertEquals(testTree.allCodes(), "");

  }

}