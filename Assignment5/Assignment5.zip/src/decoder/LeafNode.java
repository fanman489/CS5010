package decoder;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class LeafNode extends AbstractNode {

  private char symbol;


  public LeafNode(char codedChar, String name) {
    super(name);
    symbol = codedChar;

  }

  public TreeNode addLeafs(String parentNode, TreeNode leaf) {
    String parentName = parentNode.substring(0, parentNode.length() - 1);


    System.out.println(parentName + "parent" + parentNode);


    if (parentName.equals(this.getCodeName())) {
      GroupNode newGroupNode = new GroupNode(parentName);
      newGroupNode.addLeafs(parentName, leaf);
      return newGroupNode;
    }
    return this;

  }

  public List<TreeNode> toList() {
    List<TreeNode> result = new ArrayList<TreeNode>();
    result.add(this);
    return result;
  }

  public String getCodeName() {
    return "Symbol:" + symbol + "Codename:" + this.getCodeName();
  }



}
