package decoder;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DecoderImpl implements Decoder {

  TreeNode root;

  public DecoderImpl(String name) {
    root = new GroupNode(name);
  }

  public void addCode(char symbol, String code) {

    char searchChar;
    String tempCode = "";
    int countCode;


    //Cycle through the string code, if the code doesnt exist, create a path to it
    for (int i = 0; i < code.length(); i++) {
      searchChar = code.charAt(i);
      tempCode = tempCode + searchChar;
      countCode = root.countCode(tempCode);

      //Will attempt to add path
      if (countCode == 0) {
        TreeNode newCode = new LeafNode(symbol, tempCode);
        root = root.addLeafs(tempCode, newCode);
      }

    }
  }

  public String allCodes() {
    List<String> leafList = new ArrayList<String>();
    leafList = root.toList().stream().map(e -> e.getCodeName()).collect(Collectors.toList());
    String output = "";

    for (int i = 0; i < leafList.size(); i++) {
      output = output + leafList.get(i).toString();
    }
    return leafList.toString();
  }


}
