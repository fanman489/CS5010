package decoder;

import java.util.List;
import java.util.function.Predicate;

public interface TreeNode {

  public TreeNode addLeafs(char parentNode, TreeNode leaf);

  public char getCodeName();

  public List<TreeNode> toList();

  public int countCode(String code);
}
