package decoder;

import java.util.function.Predicate;

public abstract class AbstractNode implements TreeNode {

  private final char codeName;

  public AbstractNode(char name) {
    codeName = name;
  }

  public char getCodeName() {
    return codeName;
  }

  public int countCode(String code) {
    if (this.codeName.equals(code)) {
      return 1;
    }

    return 0;
  }




}
