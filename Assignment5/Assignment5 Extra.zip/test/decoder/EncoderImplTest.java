package decoder;

import org.junit.Test;

import encoder.EncoderImpl;

import static org.junit.Assert.*;

public class EncoderImplTest {

  EncoderImpl test = new EncoderImpl("01");

  @Test
  public void testConstructor() {

    //test.getFrequency("Hello world.");
    assertEquals(test.getPriority().poll().getOutput(), " :1\n");
    assertEquals(test.getPriority().poll().getOutput(), ".:1\n");
    assertEquals(test.getPriority().poll().getOutput(), "H:1\n");
    assertEquals(test.getPriority().poll().getOutput(), "d:1\n");
    assertEquals(test.getPriority().poll().getOutput(), "e:1\n");

  }

  @Test
  public void testEncode() {

    test.generateHash("Hello wooooooorld");

    assertEquals(test.outputHash(), " :1\n");

  }

}