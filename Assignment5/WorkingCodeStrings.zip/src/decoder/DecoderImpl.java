package decoder;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DecoderImpl implements Decoder {

  TreeNode root;

  public DecoderImpl(String name) {
    root = new GroupNode(name);
  }

  public void addCode(char symbol, String code) {

    char searchChar;
    String tempCode = "";
    int countCode;

    List<Character> leafList = new ArrayList<Character>();
    leafList = root.toList().stream().map(e -> e.getSymbol()).collect(Collectors.toList());
    if (leafList.contains(symbol)) {
      throw new IllegalArgumentException("This symbol already input.");
    }


    //Cycle through the string code, if the code doesnt exist, create a path to it
    for (int i = 0; i < code.length(); i++) {

      searchChar = code.charAt(i);
      tempCode = tempCode + searchChar;
      countCode = root.countCode(tempCode);

      //Will attempt to add path
      if (countCode == 0) {
        if (i == code.length()-1) {
          TreeNode newCode = new LeafNode(symbol, tempCode);
          root = root.addLeafs(tempCode.substring(0, tempCode.length() - 1), newCode);
        } else {
          TreeNode newCode = new GroupNode(tempCode);
          root = root.addLeafs(tempCode.substring(0, tempCode.length() - 1), newCode);
        }
      }

    }
  }

  public String allCodes() {
    List<String> leafList = new ArrayList<String>();
    leafList = root.toList().stream().map(e -> e.getCodeNameAndSymbol()).collect(Collectors.toList());
    String output = "";

    for (int i = 0; i < leafList.size(); i++) {
      output = output + leafList.get(i) + "\n";
    }
    return output;
  }


  public String decode(String code) {

    char searchChar;
    String tempCode = Character.toString(code.charAt(0));
    int codeLength = code.length();
    String output = "";

    TreeNode current = root;

    for (int i = 1; i < code.length(); i++) {
      searchChar = code.charAt(i);
      tempCode = tempCode + searchChar;

      TreeNode leaf = current.checkNode(tempCode);

      if (leaf.getSymbol() != null ) {
        output = output + leaf.getSymbol();
        codeLength = codeLength - i - 1;
        break;
      }
      if (leaf != null) {
        current = leaf;
      }
    }

    if (codeLength > 0) {
      output = output + this.decode(code.substring(tempCode.length()));
    }

    return output;
  }


  public boolean isCodeComplete() {
    int numberOfNodes = root.getLeafs().size();
    return root.checkNumberofNodes(numberOfNodes);
  }





}
