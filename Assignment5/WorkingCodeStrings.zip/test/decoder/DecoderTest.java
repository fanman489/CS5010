package decoder;

import org.junit.Before;
import org.junit.Test;

import org.junit.Assert;

import static org.junit.Assert.assertEquals;

public class DecoderTest {

  Decoder testTree = new DecoderImpl("1");

  @Test
  public void testAddTree() {

    assertEquals(testTree.allCodes(), "");

    testTree.addCode('b',"10");
    testTree.addCode('c',"1216");
    //testTree.addCode('c',"1311");
    testTree.addCode('-',"132");
    testTree.addCode('r',"1212");
    testTree.addCode('a',"1214");
    testTree.addCode('t',"1213");
    testTree.addCode('u',"143");
    testTree.addCode('v',"134");

    //assertEquals(testTree.decode("12110121132"), "");

    assertEquals(testTree.allCodes(), "");

  }


  @Test
  public void testDecode() {

    assertEquals(testTree.allCodes(), "");

    testTree.addCode('b',"10");
    testTree.addCode('c',"121");
    //testTree.addCode('c',"1311");
    testTree.addCode('-',"132");

    assertEquals(testTree.decode("12110121132"), "cbc-");
    assertEquals(testTree.decode("13"), "cbc-");


  }
  @Test
  public void testTreeComplete() {

    testTree.addCode('b',"122");
    testTree.addCode('c',"111");
    testTree.addCode('c',"121");
    testTree.addCode('d',"123");

    //assertEquals(testTree.decode("12110121132"), "");

    assertEquals(testTree.isCodeComplete(), "");

  }

}