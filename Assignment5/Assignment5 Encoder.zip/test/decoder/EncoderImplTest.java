package decoder;

import org.junit.Test;

import encoder.EncoderImpl;

import static org.junit.Assert.*;

public class EncoderImplTest {

  EncoderImpl test = new EncoderImpl("01");

  @Test
  public void testConstructor() {

    //test.getFrequency("Hello world.");
    assertEquals(test.getPriority().poll().getOutput(), " :1\n");
    assertEquals(test.getPriority().poll().getOutput(), ".:1\n");
    assertEquals(test.getPriority().poll().getOutput(), "H:1\n");
    assertEquals(test.getPriority().poll().getOutput(), "d:1\n");
    assertEquals(test.getPriority().poll().getOutput(), "e:1\n");

  }

  @Test
  public void testEncode() {

    assertEquals("1100111101010010101101001000111101011", test.encode("Hello World."));

    EncoderImpl testDecodeEncode = new EncoderImpl("01");
    Decoder testDecode = testDecodeEncode.createTree("Hello World.");
    assertEquals("Hello World.", testDecode.decode("1100111101010010101101001000111101011"));


  }

  @Test
  public void testEncodeWikipedia() {

    assertEquals("1100111101010010101101001000111101011", test.encode("Hello World."));

    EncoderImpl testDecodeEncode = new EncoderImpl("01");
    Decoder testDecode = testDecodeEncode.createTree("Hello World.");
    assertEquals("Hello World.", testDecode.decode("1100111101010010101101001000111101011"));


  }

}