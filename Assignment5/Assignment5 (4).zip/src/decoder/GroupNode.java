package decoder;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class GroupNode extends AbstractNode{

  private List<TreeNode> leafs;

  protected GroupNode(String name) {
    super(name);
    leafs = new LinkedList<TreeNode>();
  }

  public TreeNode addLeafs(String parentNode, TreeNode leaf) throws RuntimeException {

    if (parentNode.equals(this.getCodeName())) {
      if (checkLeafsForAdding(parentNode, leaf.getCodeName())) {
        this.leafs.add(leaf);
        return this;
      } else {
        throw new RuntimeException("Cannot add this node.");
      }
    }
    for (int i = 0; i< this.leafs.size(); i++) {
      this.leafs.set(i, this.leafs.get(i).addLeafs(parentNode, leaf));
    }

    return this;
  }


  private boolean checkLeafsForAdding(String parentNodeName, String nameCheck) {
    for (int i = 0; i< this.leafs.size(); i++) {
      if(this.leafs.get(i).getCodeName() == nameCheck && this.leafs.get(i).getClass().toString() == "GroupNode") {
        return false;
      }
    }

    return true;
  }


  public List<TreeNode> toList() {

    List<TreeNode> result = new ArrayList<TreeNode>();
    for (TreeNode e:leafs) {
      result.addAll(e.toList());
    }
    return result;
  }

  public int countCode(String code) {
    Stream<TreeNode> stream = this.leafs.stream();
    return this.leafs.stream().mapToInt(b -> b.countCode(code)).sum() + super.countCode(code);
  }

  @Override
  public TreeNode checkNode(String check) {

    if (leafs != null) {
      for (TreeNode eachLeaf:leafs) {
        if (eachLeaf.getCodeName().equals(check)){
          return eachLeaf;
        }
      }
    }
    return null;
  }

  @Override
  public boolean checkNumberofNodes(int compare) {
    int size = leafs.size();

    if (size - compare != 0) {
      return false;
    }

    for (TreeNode eachLeaf:leafs) {
      if (!eachLeaf.checkNumberofNodes(compare)) {
        return false;
      }
    }

    return true;
  }


  public List<TreeNode> getLeafs() {
    return leafs;
  }


}
