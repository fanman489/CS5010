package decoder;

import org.junit.Before;
import org.junit.Test;

import org.junit.Assert;

import static org.junit.Assert.assertEquals;

public class DecoderTest {

  Decoder testTree = new DecoderImpl("1");

  @Test
  public void testAddTree() {

    testTree.addCode('b',"10");
    testTree.addCode('c',"121");
    //testTree.addCode('c',"1311");
    testTree.addCode('b',"132");

    //assertEquals(testTree.decode("12110121132"), "");

    assertEquals(testTree.allCodes(), "");

  }

  @Test
  public void testTreeComplete() {

    testTree.addCode('b',"122");
    testTree.addCode('c',"111");
    testTree.addCode('c',"121");
    testTree.addCode('d',"123");

    //assertEquals(testTree.decode("12110121132"), "");

    assertEquals(testTree.isCodeComplete(), "");

  }

}