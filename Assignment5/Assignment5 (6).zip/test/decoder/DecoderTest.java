package decoder;

import org.junit.Before;
import org.junit.Test;

import org.junit.Assert;

import static org.junit.Assert.assertEquals;

public class DecoderTest {

  Decoder testTree = new DecoderImpl();

  @Test
  public void testAddTree() {

    assertEquals(testTree.allCodes(), "");

    testTree.addCode('b',"10");
    testTree.addCode('c',"1216");
    testTree.addCode('d',"4311");
    testTree.addCode('-',"132");
    testTree.addCode('r',"1212");


    //assertEquals(testTree.decode("12110121132"), "");

    assertEquals(testTree.allCodes(), "");

  }


  @Test
  public void testDecode() {

    //assertEquals(testTree.allCodes(), "");

    testTree.addCode('b',"10");
    testTree.addCode('c',"121");
    //testTree.addCode('c',"1311");
    testTree.addCode('-',"132");

    //assertEquals(testTree.decode("1012113212110"), "cbc-");
    assertEquals(testTree.decode("13"), "cbc-");


  }
  @Test
  public void testTreeComplete() {

    testTree.addCode('b',"12");
    testTree.addCode('c',"11");
    testTree.addCode('a',"21");
    testTree.addCode('d',"22");

    //assertEquals(testTree.decode("12110121132"), "");

    assertEquals(testTree.isCodeComplete(), "");

  }

}