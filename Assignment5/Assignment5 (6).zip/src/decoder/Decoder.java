package decoder;

public interface Decoder {

  void addCode(char symbol, String code);

  String decode(String encodedMessage);

  String allCodes();

  boolean isCodeComplete();

}
