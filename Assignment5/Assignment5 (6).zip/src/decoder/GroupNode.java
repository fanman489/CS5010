package decoder;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class GroupNode extends AbstractNode{

  private List<TreeNode> leafs;

  protected GroupNode(char name) {
    super(name);
    leafs = new LinkedList<TreeNode>();
  }

  protected GroupNode() {
    super(null);
    leafs = new LinkedList<TreeNode>();
  }

  public TreeNode addLeafs(TreeNode leaf) throws RuntimeException {

   if (checkLeafsForAdding(leaf.getCodeName())) {
     this.leafs.add(leaf);
   } else {
     throw new RuntimeException("Cannot add this node." + leaf.getCodeName() + " " + this.getCodeName());
   }
   return leaf;
  }


  private boolean checkLeafsForAdding(char nameCheck) {
    for (int i = 0; i< this.leafs.size(); i++) {
      if(this.leafs.get(i).getCodeName() == nameCheck && this.leafs.get(i).getSymbol() != null) {
        System.out.println(nameCheck + " " + this.leafs.get(i).getCodeName());
        return false;
      }
    }

    return true;
  }


  public List<TreeNode> toList() {

    List<TreeNode> result = new ArrayList<TreeNode>();
    for (TreeNode e:leafs) {
      result.addAll(e.toList());
    }
    return result;
  }


  @Override
  public TreeNode checkNode(char check) {

    if (leafs != null) {
      for (TreeNode eachLeaf:leafs) {
        if (eachLeaf.getCodeName() == check) {
          return eachLeaf;
        }
      }
    }
    return null;
  }

  @Override
  public boolean checkNumberofNodes(int compare) {
    int size = leafs.size();

    if (size - compare != 0) {
      return false;
    }

    for (TreeNode eachLeaf:leafs) {
      if (!eachLeaf.checkNumberofNodes(compare)) {
        return false;
      }
    }

    return true;
  }


  public List<TreeNode> getLeafs() {
    return leafs;
  }


}
