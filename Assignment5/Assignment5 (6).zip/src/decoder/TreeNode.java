package decoder;

import java.util.List;
import java.util.function.Predicate;

public interface TreeNode {

  public TreeNode addLeafs(TreeNode leaf);

  public char getCodeName();

  public List<TreeNode> toList();

  public int countCode(char code);

  public String getCodeNameAndSymbol();

  public TreeNode checkNode(char code);

  public Character getSymbol();

  public boolean checkNumberofNodes(int compare);

  public List<TreeNode> getLeafs();


}
