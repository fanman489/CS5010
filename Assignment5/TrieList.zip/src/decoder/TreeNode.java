package decoder;

import java.util.List;
import java.util.function.Predicate;

public interface TreeNode {

  public List<TreeNode> toList();

  public TreeNode checkNodes(char c);

  public List<TreeNode> getLeafs();

  public void incrementCount();

  public char getCodeName();

  public String getPathAndSymbol();
}
