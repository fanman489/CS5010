package decoder;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;

public abstract class AbstractNode implements TreeNode {

  private final char codeName;
  private List<TreeNode> leafs;
  int count;
  private String codePath;
  private char symbol;



  public AbstractNode(char name) {
    codeName = name;
    leafs = new LinkedList<TreeNode>();
    count = 0;
    codePath = "";
  }

  public char getCodeName() {
    return codeName;
  }

  public List<TreeNode> getLeafs() {
    return leafs;
  }

  public void incrementCount() {
    count = count + 1;
  }

  public void setCodePath(String path) {
    codePath = path;
  }

  public void setSymbol(char c) {
    symbol = c;
  }

  public String getPathAndSymbol() {
    return "Code:" + codePath + " Symbol: " + symbol;
  }




}
