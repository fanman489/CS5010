package decoder;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class GroupNode extends AbstractNode{

  private List<TreeNode> leafNodes;


  public GroupNode(char name) {
    super(name);
    leafNodes = this.getLeafs();
  }



  public TreeNode checkNodes(char check) {
    if (leafNodes != null) {
      for (TreeNode eachLeaf: leafNodes) {
        if (eachLeaf.getCodeName() == check) {
          return eachLeaf;
        }
      }
    }
    return null;
  }
  public List<TreeNode> toList() {
    List<TreeNode> result = new ArrayList<TreeNode>();
    for (TreeNode e:leafNodes) {
      result.addAll(e.toList());
    }
    return result;
  }






}
