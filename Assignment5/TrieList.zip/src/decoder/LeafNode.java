package decoder;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class LeafNode extends AbstractNode {


  public LeafNode(char symbolChar, char code, String path) {
    super(code);
    this.setSymbol(symbolChar);
    this.setCodePath(path);


  }

  public TreeNode checkNodes(char check) {
    return null;
  }

  public List<TreeNode> toList() {
    List<TreeNode> result = new ArrayList<TreeNode>();
    result.add(this);
    return result;
  }





}
