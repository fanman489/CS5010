package decoder;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DecoderImpl implements Decoder {

  TreeNode root;

  public DecoderImpl(char start) {
    root = new GroupNode(start);
  }

  public void addCode(char symbol, String code) {

    TreeNode current = root;
    int i = 1;
    for (char c:code.toCharArray()) {
      TreeNode leaf = current.checkNodes(c);
      if (leaf != null) {
        current = leaf;
      } else {
        if (i == code.length()) {
          current.getLeafs().add(new LeafNode(symbol, c, code));
        } else {
          current.getLeafs().add(new GroupNode(c));
        }
      }
      current.incrementCount();
      i++;
    }


  }


  public String allCodes() {
    List<String> leafList = new ArrayList<String>();
    leafList = root.toList().stream().map(e -> e.getPathAndSymbol()).collect(Collectors.toList());
    String output = "";

    for (int i = 0; i < leafList.size(); i++) {
      output = output + leafList.get(i).toString();
    }
    return leafList.toString();
  }



}
